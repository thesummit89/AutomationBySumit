package pom;

import basetest.TestBase;
import org.apache.commons.lang3.tuple.Pair;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utility.ControlActions;
import utility.JasonParser;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;


public class MessageEnquiry extends TestBase {

    public MessageEnquiry(WebDriver driver){

        PageFactory.initElements(driver, this);
    }

    public MenuSelection menuselection = new MenuSelection(driver);


    ControlActions controlactions = new ControlActions(driver);

    @FindBy(xpath = Locators.SSSMSGENQSEARCHMBTN_XPATH)
    public WebElement btnmsgenqsearch;
    @FindBy(xpath = Locators.SSSMSGENQMSGTYPEDDL_XPATH)
    public WebElement ddlmsgtype;
    @FindBy(xpath = Locators.SSSMSGENQMSGTYPEDDLTXT_XPATH)
    public WebElement txtmsgtype;
    @FindBy(xpath = Locators.SSSMSGENQMSGTYPEDDLLIST_XPATH)
    public WebElement drpmessgaetype;
    @FindBy(xpath = Locators.SSSMSGENQSEARCHBTN_XPATH)
    public WebElement btnfiltersearch;
    @FindBy(xpath = Locators.SSSMSGENQMESGID_XPATH)
    public WebElement txtmessageid;
    @FindBy(xpath = Locators.SSSMSGENQBY_XPATH)
    public WebElement drpenquireby;
    @FindBy(xpath = Locators.SSSMSGENQVIEWBY_XPATH)
    public WebElement drpviewby;
    @FindBy(xpath = Locators.SSSMSGENQRESULTTAB_XPATH)
    public WebElement tabmessageenquiry;
    @FindBy(xpath = Locators.SSSMSGENQBY_XPATH)
    public WebElement drpnquireby;
    @FindBy(xpath = Locators.SSSMSGENQRESETBTN_XPATH)
    public WebElement btnreset;


    List<Pair<String, String>> listOfPairs = new ArrayList<Pair<String,String>>();

    public MessageEnquiry SerchFilter(String...args) throws InterruptedException {

        //ddlmsgtype.click();
        //search criteria in main page
        for (String arg : args) {
            String[] parts = arg.split(":");
            int len = parts.length;
            String value="";
            String key = parts[0];
            if (len == 2) {
                 value = parts[1];
            }
            int searchflag = 0;
            if (!value.equals("")){
                if (key.equals("viewby")) {
                    drpviewby.click();
                    controlactions.SelectDropDownListItem(drpviewby,value);
                    searchflag = 1;
                }else if (key.equals("enquireby")){
                    drpenquireby.click();
                    controlactions.SelectDropDownListItem(drpenquireby,value);
                    searchflag = 1;
                }

                if (searchflag==1) {
                    btnmsgenqsearch.click();
                    Thread.sleep(1000);
                    btnreset.click();
                    searchflag++;
                }
                switch (key.toLowerCase()) {

                    case "messageid":
                        //String messageid = "XSDTIFORMAT";
                        controlactions.entertxtinwebelement(txtmessageid,value);
                        break;
                    case "messagesender":

                        break;
                    case "messagereceiver":
                        break;
                    case "messagetype":
                        //String listitem = "xcop.001";
                        ddlmsgtype.click();
                        Thread.sleep(500);
                        controlactions.UlDropDownListItem(By.xpath(Locators.SSSMSGENQMSGTYPEDDLLIST_XPATH) , value);
                        break;
                    case "sssreference":

                        break;
                    case "senderreference":

                        break;

                    case "senderswiftbic":

                        break;
                    case "receiverswiftbic":

                        break;

                    case "messagesendtime":

                        break;
                    case "messageendtime":

                        break;
                }

            }

        }
        btnfiltersearch.click();
        return this;
    }


    public MessageEnquiry errormessagevalidation() throws InterruptedException, IOException, ParseException {
        menuselection.MenuseSelection("lnk_settlement","lnk_MessageEnquiry_");

        //String listitem = "xcop.001";
        //controlactions.getcelldatafromtable(tabmessageenquiry,"","XSDSETTAMTELENA109");
    //    SerchFilter("viewby:","enquireby:Erroneous Message","messageid:XSDVALTPEMPTY046","messagetype:sese.023");
        //controlactions.SelectDropDownListItem(listitem, drpmessgaetype);
        //controlactions.SelectDropDownListItem(drpnquireby,"Erroneous Message");
        Thread.sleep(1000);
        JasonParser jasonParser = new JasonParser();
        String datafilepath = "src/test/testdata/TC01_SSS_function_messageenqury/TC01_SSS_function_messageenqury_data.jason";
        String messageid = jasonParser.getjsontestdata(datafilepath,"messageid");
        //String messagetype = jasonParser.getjsontestdata(datafilepath,"messagetype");
        //messagetype = messagetype.substring(0,8);
        SerchFilter("viewby:","enquireby:Erroneous Message","messageid:" + messageid,"messagetype:");
        Thread.sleep(5000);
        int rownumber = controlactions.getcelldatafromtable1(tabmessageenquiry,messageid);

        if (rownumber > 0) {
            System.out.println("Row number with the desired value: " + rownumber);

        } else {
            System.out.println("Value not found in the table.");
        }
        //validate the data in record table

        return this;
    }



}
