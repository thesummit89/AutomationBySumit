package pom;

public class Locators {
	/*** Below locators for Login Page ******************/

	public static final String SSSLOGINMEMCODE_XPATH = "//input[@id='txt_param3']";
	public static final String SSSLOGINUSERID_XPATH = "//input[@id='txt_param1']";
	public static final String SSSLOGINPASS_XPATH = "//input[@id='txt_param2']";
	public static final String SSSLOGINBUTTON_XPATH = "//button[@type = 'submit']";
	public static final String SSSLOGINERROR_XPATH1 = "//div[@class='input-mode'']/input[@id=";
	public static final String SSSLOGINERROR_XPATH2 = "]//following-sibling::div/span[contains(text(),";
	public static final String SSSLOGINERROR_XPATH3 = ")]";

	/*** Below locators for Home Page ******************/
	public static final String SSSHOMEPAGETITLE_XPATH = "//h1";
	//public static final String SSSMAINMENU_XPATH = "//a[@id='lnk_allotment']";
	public static final String SSSMAINMENU1_XPATH = "//a[@id='";
	public static final String SSSMAINMENU2_XPATH = "']";
	//public static final String SSSSUBMENU_XPATH = "//a[contains(text(),'Allotment Enquiry')]"; //"//a[@id='lnk_AllotmentEnquiry_']"
	public static final String SSSSUBMENU1_XPATH = "//a[@id='";
	public static final String SSSSUBMENU2_XPATH = "']"; //"//a[@id='lnk_AllotmentEnquiry_']"
	public static final String SSSLOGOUT_XPATH = "//i[@class='fa fa-sign-out-alt']";
	public static final String SSSLOGOUTCONFIRMBTN_XPATH = "//button[@id='btn_okModal' and contains(text(),'Confirm') ]";

	/*** Below locators for message enquire Page ******************/
	public static final String SSSMSGENQSEARCHMBTN_XPATH  = "//button[@id='btn_toggleSearch']";
	public static final String SSSMSGENQSEARCHMSGID_XPATH  = "//input[@id='txt_messageId']";
	public static final String SSSMSGENQMSGTYPEDDL_XPATH = "//div[@id='fdrp_messageType_toggle']";
	public static final String SSSMSGENQMSGTYPEDDLTXT_XPATH = "//input[@id='fdrp_messageType']";
	public static final String SSSMSGENQMSGTYPEDDLLIST_XPATH =  "//ul/li";
	public static final String SSSMSGENQMSGTYPEDDLITEM_XPATH =  "//button[@class='dropdown-item']";///span[contains(text(),'camt.054')]";
	public static final String SSSMSGENQMESGID_XPATH = "//input[@id='txt_messageId']";
	public static final String SSSMSGENQSEARCHBTN_XPATH =  "//button[@id='btn_search']";
	public static final String SSSMSGENQRESETBTN_XPATH  = "//button[@id='btn_reset']";
	public static final String SSSMSGENQRESULTTAB_XPATH =  "//table[@id='result_table']";
	public static final String SSSMSGENQBY_XPATH = "//span[contains(text(),'Enquire By')]/parent::*/parent::*/following-sibling::*";//select[@id='drp_171706371434348']";
	public static final String SSSMSGENQVIEWBY_XPATH = "//span[contains(text(),'View By')]/parent::*/parent::*/following-sibling::*"; //select[@id='drp_171706371434383']";

}
