package pom;

import basetest.TestBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static org.testng.Assert.assertEquals;

public class LoginPageSSS extends TestBase {

    public LoginPageSSS(WebDriver driver) {

        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = Locators.SSSLOGINMEMCODE_XPATH)
    public WebElement memcode;
    @FindBy(xpath = Locators.SSSLOGINUSERID_XPATH)
    public WebElement username;
    @FindBy(xpath = Locators.SSSLOGINPASS_XPATH)
    public WebElement password;
    @FindBy(xpath = Locators.SSSLOGINBUTTON_XPATH)
    public WebElement loginbutton;


    public LoginPageSSS launchurl() throws InterruptedException {
        driver.get(prop.getProperty("url"));
        Thread.sleep(5000);
        return this;
    }
    public LoginPageSSS loginMemeber() throws InterruptedException {
        launchurl();
        memcode.sendKeys("MASGSGSC");
        username.sendKeys("ac_myat_opr");
        password.sendKeys("123");
        loginbutton.click();
        Thread.sleep(5000);

        return this;
    }
    public LoginPageSSS enterUserName() {
        username.sendKeys("ac_myat_opr");
        return this;
    }
    public LoginPageSSS enterPassword() {
        password.sendKeys("123");
        return this;
    }
    public LoginPageSSS clickOnLoginButton() throws InterruptedException {
        loginbutton.click();
        Thread.sleep(5000);
        return this;
    }
}
