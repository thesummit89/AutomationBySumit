package pom;

import basetest.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class MenuSelection extends TestBase {
    public MenuSelection(WebDriver driver){
        PageFactory.initElements(driver, this);
    }

    public void MenuseSelection(String mainmenu, String submenu){
        WebElement elemainmenu = driver.findElement(By.xpath(Locators.SSSMAINMENU1_XPATH+mainmenu+Locators.SSSMAINMENU2_XPATH));
        elemainmenu.click();
        //WebElement submenu = driver.findElement(By.xpath(Locators.SSSSUBMENU1_XPATH+subMenu+Locators.SSSSUBMENU2_XPATH));
        new WebDriverWait(driver, Duration.ofSeconds(1L)).until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.SSSSUBMENU1_XPATH+submenu+Locators.SSSSUBMENU2_XPATH))).click();
        //submenu.click();

    }
}
