package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import basetest.TestBase;

import java.time.Duration;

public class HomePage extends TestBase {
	 
	 public HomePage(WebDriver driver) {
	 	PageFactory.initElements(driver, this);

	 }
	@FindBy(xpath = Locators.SSSLOGOUT_XPATH)
	public WebElement logOut;
	 @FindBy(xpath = Locators.SSSLOGOUTCONFIRMBTN_XPATH)
	 public WebElement logOutConfirmBtn;


	public HomePage menuSelection(String mainMenu, String subMenu) throws InterruptedException {
		WebElement mainmenu = driver.findElement(By.xpath(Locators.SSSMAINMENU1_XPATH+mainMenu+Locators.SSSMAINMENU2_XPATH));
		mainmenu.click();
		//WebElement submenu = driver.findElement(By.xpath(Locators.SSSSUBMENU1_XPATH+subMenu+Locators.SSSSUBMENU2_XPATH));
		new WebDriverWait(driver, Duration.ofSeconds(1L)).until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.SSSSUBMENU1_XPATH+subMenu+Locators.SSSSUBMENU2_XPATH))).click();
		//submenu.click();

		return this;
	}

	public HomePage logout() throws InterruptedException {
		logOut.click();
		Thread.sleep(2000);
		logOutConfirmBtn.click();
	 	return this;
	}
}
