package testcases;

import basetest.TestBase;


import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebDriver;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pom.HomePage;
import pom.LoginPageSSS;
import pom.MessageEnquiry;
import utility.PublishErrorMessagePayload;

import java.io.IOException;

public class SSSFunctionalTest extends TestBase {
    public WebDriver driver;

    @BeforeMethod
    public void launchdriver(){

        driver = launchDriver();
    }

    @Test(priority = 1)
    public void TC01_SSS_function_messageenqury() throws InterruptedException, IOException, ParseException {
       //Trigger Botool Test case
        PublishErrorMessagePayload publisherrmegpayload =  new PublishErrorMessagePayload();
        String messagefilepath = "src//test//testdata//TC01_SSS_function_messageenqury//sese33_Message_Validation_Failure.json";
        publisherrmegpayload.publishErrorMsgTran(messagefilepath);
        Thread.sleep(5000);
        LoginPageSSS loginpage = new LoginPageSSS(driver);
        HomePage homepage =  new HomePage(driver);
        MessageEnquiry  messageenquiry = new MessageEnquiry(driver);
        loginpage.loginMemeber();
        //homepage.menuSelection("lnk_settlement","lnk_MessageEnquiry_");
        messageenquiry.errormessagevalidation();

    }

    @AfterMethod
    public void closeBrowser() throws InterruptedException {
           /* HomePage homepage =  new HomePage(driver);
            homepage.logout();
            driver.close();*/

    }
}
