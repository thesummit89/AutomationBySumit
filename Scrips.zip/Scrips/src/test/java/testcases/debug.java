package testcases;

import basetest.TestBase;


import org.openqa.selenium.WebDriver;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pom.*;
import utility.ControlActions;

public class debug extends TestBase {
    public WebDriver driver;
    @FindBy(xpath = Locators.SSSMSGENQBY_XPATH)
    public WebElement drpenquireby;
    @FindBy(xpath = Locators.SSSMSGENQVIEWBY_XPATH)
    public WebElement drpviewby;


    @BeforeMethod
    public void launchdriver(){

        driver = launchDriver();
    }

    @Test(priority = 1)
    public void TC01_SSS_function_messageenqury() throws InterruptedException {
        LoginPageSSS loginpage = new LoginPageSSS(driver);
        HomePage homepage =  new HomePage(driver);
        MessageEnquiry  messageenquiry = new MessageEnquiry(driver);
        MenuSelection menuselection = new MenuSelection(driver);
        ControlActions controlActions = new ControlActions(driver);
        loginpage.loginMemeber();
        //homepage.menuSelection("lnk_settlement","lnk_MessageEnquiry_");
        menuselection.MenuseSelection("lnk_settlement","lnk_MessageEnquiry_");
        drpenquireby.click();
        controlActions.SelectDropDownListItem(drpenquireby,"Erroneous Message");
        //controlActions.getcelldatafromtable(tabmessageenquiry,"","SCTIESFINCGINSTR");

    }

    @AfterMethod
    public void closeBrowser() throws InterruptedException {
           /* HomePage homepage =  new HomePage(driver);
            homepage.logout();
            driver.close();*/

    }
}
