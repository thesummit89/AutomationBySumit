package testcases;


import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import basetest.TestBase;
import pom.HomePage;

public class E2ETest extends TestBase{
	 HomePage page = new HomePage(driver);
	
	
	
	
	 @Test
	 public void e2e_test_run() throws InterruptedException {
		

		 
	
		 
	 }
	 
	 @Test
	 public void e2e_test2() throws InterruptedException {
		

	 
	 }
	 

}
