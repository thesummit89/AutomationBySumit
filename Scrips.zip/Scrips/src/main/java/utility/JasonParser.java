package utility;

import basetest.TestBase;
import com.google.gson.JsonObject;
import org.json.JSONObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonParser;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import java.io.FileReader;
import java.io.IOException;


public class JasonParser extends TestBase {
    public String getjsontestdata(String filePath, String key) throws IOException, ParseException, ParseException {
        /*
        //String dataFilePath = "ssrc/test/testdata/TC01_SSS_function_messageenqury/";
        JSONObject testObject = null;
        FileReader reader = new FileReader(filePath);
        JSONParser jsonParser = new JSONParser();
        Object obj=jsonParser.parse(reader);
        JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
        testObject = (JSONObject) jsonObject;
        String value = testObject.get(key).toString();
        return value;
        */


        //String jsonFilePath = "path/to/your/data.json";
        JsonParser parser = new JsonParser();

        String value = null;
        try (FileReader reader = new FileReader(filePath)) {
            JsonObject jsonObject = (JsonObject) parser.parse(reader);
            // Retrieve the value associated with the key 'yourKey'
            value = jsonObject.get(key).getAsString();
            System.out.println("Value for 'yourKey': " + value);
            return value;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;
    }

    }
