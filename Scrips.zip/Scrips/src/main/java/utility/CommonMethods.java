package utility;

public class CommonMethods {

}
