package utility;

public class Constant {
	public static String EXECUTION_REPORT_PATH, SCREENSHOT_PATH_FAIL, SCREENSHOT_PATH_PASS;
	public static final String CONFIG_PATH= System.getProperty("user.dir")+"\\resources\\config.properties";
	final public static String PROJECTPATH = System.getProperty("user.dir") + "/test-output/reports";

}
