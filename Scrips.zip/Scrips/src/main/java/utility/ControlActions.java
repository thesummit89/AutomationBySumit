package utility;


import basetest.TestBase;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.io.IOException;
import java.time.Duration;
import java.util.List;

public class ControlActions extends TestBase {
    WebDriver driver;
    public Actions action;
    public WebDriverWait wait;
    public ControlActions(WebDriver driver){
        this.driver = driver;
        action = new Actions(this.driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        //For Sauce Run it has been observed that element are getting timeout so added more time
        PageFactory.initElements(driver, this);
    }
    public ControlActions UlDropDownListItem(By element, String listitem) {
        //txtmsgtype.sendKeys("camt.054");
        //List<WebElement> allOptions=driver.findElements(By.cssSelector("ul li"));

        List<WebElement> allOptions= driver.findElements(element);

        //String listitem="camt.054";

        for(int i=0; i<allOptions.size(); i++) {

            if(allOptions.get(i).getText().contains(listitem)) {
                allOptions.get(i).click();
                System.out.println("clicked");
                break;
            }
        }
        return this;
    }

    public ControlActions SelectDropDownListItem(WebElement element, String listitem) throws InterruptedException {
        //txtmsgtype.sendKeys("camt.054");
        //List<WebElement> allOptions=driver.findElements(By.cssSelector("ul li"));
        //List<WebElement> allOptions= driver.findElements(By.xpath("//li/button/span"));
        Select select = new Select(element);
        select.selectByVisibleText(listitem);
        Thread.sleep(1000);
       /* List<WebElement> allOptions= driver.findElements(element);
        //String listitem="camt.054";

        for(int i=0; i<allOptions.size(); i++) {

            if(allOptions.get(i).getText().contains(listitem)) {
                allOptions.get(i).click();
                System.out.println("clicked");
                break;
            }
        }*/
        return this;
    }

    public ControlActions entertxtinwebelement(WebElement element, String messageid){
        element.sendKeys(messageid);
        return this;
    }

    public ControlActions getcelldatafromtable(By element, String colmname, String colvalue){
        //Finding number of Rows
        //List<WebElement> rowsNumber = table.findElements(By.tagName("tr"));
        List<WebElement> rowsNumber = driver.findElements(element);
        int rowCount = rowsNumber.size();
         //Loop will execute till the last row of table.
        for (int row = 0; row < rowCount; row++) {
            //To locate columns(cells) of that specific row.
            List < WebElement > Columns_row = rowsNumber.get(row).findElements(By.tagName("td"));
            //To calculate no of columns (cells). In that specific row.
            int columns_count = Columns_row.size();
            System.out.println("Number of cells In Row " + row + " are " + columns_count);
            //Loop will execute till the last cell of that specific row.
            for (int column = 0; column < columns_count; column++) {
                // To retrieve text from that specific cell.
                String celtext = Columns_row.get(column).getText();
                System.out.println("Cell Value of row number " + row + " and column number " + column + " Is " + celtext);


            }
        }
        return this;
    }
    /****************************************************************************/

    public int getcelldatafromtable1(WebElement element,String colvalue) throws IOException, ParseException {
        // Assuming 'driver' is your WebDriver instance and 'desiredColumnIndex' is the index of the column you're searching
        WebElement table = driver.findElement(By.xpath("//table[@id='result_table']")); // Replace with your table's XPath
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        int rowNumber = 0;

        for (int i = 1; i < rows.size(); i++) {
            WebElement cell = rows.get(i).findElements(By.tagName("td")).get(1);
            if (cell.getText().equals(colvalue)) { // Replace with the value you're searching for
                rowNumber = i + 1;
                //validate th data in Message Enquiry list screen
                //String actmsgsender = rows.get(i).findElements(By.tagName("td")).get(3).getText();
                String actsenderswiftbic = rows.get(i).findElements(By.tagName("td")).get(5).getText();
                //String actmsgreciever = rows.get(i).findElements(By.tagName("td")).get(6).getText();
                //String actrecieverswiftbic = rows.get(i).findElements(By.tagName("td")).get(7).getText();
                String actmsgtype = rows.get(i).findElements(By.tagName("td")).get(8).getText();
                String actchannel = rows.get(i).findElements(By.tagName("td")).get(9).getText();
                JasonParser jasonparser = new JasonParser();
                String datafilepath = "src/test/testdata/TC01_SSS_function_messageenqury/TC01_SSS_function_messageenqury_data.jason";
                String expmsgsender = jasonparser.getjsontestdata(datafilepath,"messagesender");
                String expsenderswiftbic = jasonparser.getjsontestdata(datafilepath,"senderswiftbic");
                String expmsgreciever = jasonparser.getjsontestdata(datafilepath,"messagereciever");
                String exprecieverswiftbic = jasonparser.getjsontestdata(datafilepath,"receiverswiftbic");
                String expmsgtype = jasonparser.getjsontestdata(datafilepath,"messagetype");
                String expchannel = jasonparser.getjsontestdata(datafilepath,"channel");
                //System.out.println("Verify Message Sender in Listscreen");
                //Assert.assertEquals(actmsgsender,expmsgsender);
                System.out.println("Verify Sender Swift BIC in Listscreen: Actual   " + actsenderswiftbic + "   Expected:   " + expsenderswiftbic);
                Assert.assertEquals(actsenderswiftbic,expsenderswiftbic);
                //System.out.println("Verify Message Reciever in Listscreen");
                //Assert.assertEquals(actmsgreciever,expmsgreciever);
                //System.out.println("Verify Message Reciever in Listscreen");
                //Assert.assertEquals(actrecieverswiftbic,exprecieverswiftbic);
                System.out.println("Verify Message Type in Listscreen: Actual   " + actmsgtype + "  Expected:   " + expmsgtype );
                Assert.assertEquals(actmsgtype,expmsgtype);
                System.out.println("Verify Message Channel in Listscreen: Actual    " + actchannel + "  Expected:   " + expchannel);
                Assert.assertEquals(actchannel,expchannel);
                //validate th data from 'Erroneous Message Enquiry' popup
                WebElement celltoclick = rows.get(i).findElements(By.tagName("td")).get(11);
                celltoclick.click();

                break;
            }
        }

        /*if (rowNumber > 0) {
            System.out.println("Row number with the desired value: " + rowNumber);
        } else {
            System.out.println("Value not found in the table.");
        }*/
        return rowNumber;
    }
}
