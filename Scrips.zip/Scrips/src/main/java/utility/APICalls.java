package utility;


import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.JsonObject;
import org.json.JSONObject;
import org.openqa.selenium.remote.Response;
import io.restassured.RestAssured;

import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

//import javax.json.Json;
//import javax.json.JsonObject;
@Test
public class APICalls {
       //request the server
       /* RequestSpecification reqSpec = RestAssured.given();

        JSONObject jo = new JSONObject();
        jo.put("testSuiteId", "sese23_Business_Validation_Failure");
        jo.put("testSuiteExecutionId", "1716866345417_sese23_Business_Validation_Failure");
        jo.put("testCaseIdList", "[
                "Sese.023_Settlement Date Validation_0005"
                ]");
        jo.put("userId", "default_user");
        jo.put("apiCredentialList", "[]");
        reqSpec.body(jo.toString());

        Response resp = (Response) reqSpec.post("http://192.168.9.25:8003/api/test-suite/execute");*/
}
