package utility;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class PublishErrorMessagePayload {
    @Test
    public void publishErrorMessageTransaction1() throws IOException {

        File f = new File("resources/sese33_Message_Validation_Failure.json");
        if (f.exists()){

            InputStream is = new FileInputStream("resources/sese33_Message_Validation_Failure.json");
            String jsonTxt = IOUtils.toString(is, "UTF-8");
            System.out.println(jsonTxt);
            JSONObject json = new JSONObject(jsonTxt);
            RequestSpecification reqSpec = RestAssured.given();
            reqSpec.given().log().all().header("Content-Type","application/json").body(json.toString());
            Response resp = reqSpec.post("http://192.168.9.25:8003/api/test-suite/execute");
            //String a = json.getString("1000");
            System.out.println(resp);
            System.out.println(resp.getStatusCode());
        }
    }
    public void publishErrorMsgTran(String jasonfilepath) throws IOException {


        File f = new File(jasonfilepath);
        if (f.exists()){
            InputStream is = new FileInputStream(jasonfilepath);
            String jsonTxt = IOUtils.toString(is, "UTF-8");
            System.out.println(jsonTxt);
            JSONObject json = new JSONObject(jsonTxt);
            RequestSpecification reqSpec = RestAssured.given();
            reqSpec.given().log().all().header("Content-Type","application/json").body(json.toString());
            Response resp = reqSpec.post("http://192.168.9.25:8003/api/test-suite/execute");
            //String a = json.getString("1000");
            System.out.println(resp);
            System.out.println(resp.getStatusCode());
        }
    }

}
