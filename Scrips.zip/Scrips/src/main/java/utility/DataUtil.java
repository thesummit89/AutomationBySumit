/* retrived from C:\SCRIPS\Automation\Selenium\PageObjectModelWithPageFactories
* ds*/

package utility;


import basetest.TestBase;
import org.testng.annotations.DataProvider;

import java.lang.reflect.Method;

public class DataUtil extends TestBase {
	
	@DataProvider(name="dp")
	public Object[][] getData(Method m) {
		String sheetName = m.getName();
		int rowCount = excel.getRowCount(sheetName);
		int colCount = excel.getColumnCount(sheetName);
	
		Object[][] data = new Object[rowCount-1][colCount];
	
		
		for(int rows=2;rows<=rowCount;rows++) {
			
			for(int cols=0; cols<colCount; cols++) {
				
				data[rows-2][cols]=excel.getCellData(sheetName, cols, rows);
				
			}
			
		}
		
		
		return data;
		
	}


}
