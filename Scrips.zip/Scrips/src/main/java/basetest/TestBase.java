package basetest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.*;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;

import utility.Constant;
import utility.ExcelReader;



public class TestBase {
	
	public static Properties prop;
	public  File file = null;
	public SimpleDateFormat dateFormat;
	protected static WebDriver driver;
	public ExcelReader excel = new ExcelReader(".\\src\\test\\resources\\excel\\testdata.xlsx");

	
	/**
	 * @author -  Devloped on 13th June 2023
	 * @reportSetup - This method return configuration 
	 ***/
	@BeforeSuite
	public void reportSetUp() {
		try {
			if(prop==null) {
				prop = new Properties();
			}
			 FileInputStream fis = new FileInputStream(new File(Constant.CONFIG_PATH));
			 prop.load(fis);
		}catch(FileNotFoundException e) {

			Assert.fail("Failed because of File not found at location. PFA logs "
					+ "\n" + e.getMessage());
		}
		catch(Exception e) {
			e.printStackTrace();
			Assert.fail("Failed because of configuration. PFA logs "
					+ "\n" + e.getMessage());
		}
		
		
	}
	
	/**
	 * @author -   Devloped on 1th June 2023
	 * @reportSetup -
	 ***/
	 
	private void createFolderPath() {
		
		Date sysDate = new Date();
		dateFormat = new SimpleDateFormat("yyyy_MM_dd");
		File exedir, faildir;
		try {

			Constant.EXECUTION_REPORT_PATH = Constant.PROJECTPATH + "/ExecutionReport/" + dateFormat.format(sysDate);
			Constant.SCREENSHOT_PATH_FAIL = Constant.EXECUTION_REPORT_PATH + "/failScreenshot";

			exedir = new File(Constant.EXECUTION_REPORT_PATH);

			if (!exedir.exists()) {
				exedir.mkdir();
			}

			faildir = new File(Constant.SCREENSHOT_PATH_FAIL);
			if (!faildir.exists())
				faildir.mkdirs();

		} catch (Exception e) {
			Assert.fail("Folder not created" + e.getMessage());
		}
	}

	//@BeforeMethod
	public  WebDriver launchDriver() {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\resources\\chromeDriver\\chromedriver.exe");

		//Configuration.browserCapabilities = new ChromeOptions().addArguments("--remote-allow-origins=*");

		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		//driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;
	}
	
	

	
	

	
}
