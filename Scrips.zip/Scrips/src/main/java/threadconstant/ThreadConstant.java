package threadconstant;

public class ThreadConstant {

}
