delete from sector where code in ('DFA');
delete from sector_draft where code in ('DFA');