delete from custody_account_type where custody_account_type_id in ('A11');
delete from custody_account_type_draft where custody_account_type_id in ('A11');