package main.java.models;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class Action {
    private Integer sequence;
    private String actionType;
    private Map<String, String> data;

    // Getters and setters
    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {

        this.sequence = sequence;
    }

    public String getActionType() {

        return actionType;
    }

    public void setActionType(String actionType) {

        this.actionType = actionType;
    }

    public Map<String, String> getData() {

        return data;
    }

    public void setData(Map<String, String> data) {

        this.data = data;
    }

}
