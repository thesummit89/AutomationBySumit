package main.java.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SqlCreds {
    private String applicationId;
    private String dbUrl;
    private String dbUser;
    private String dbPassword;

    public String getApplicationId() {
        return applicationId;
    }

    public String getDbUrl() {
        return dbUrl;
    }

    public String getDbUser() {
        return dbUser;
    }

    public String getDbPassword() {
        return dbPassword;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public void setDbUrl(String dbUrl) {
        this.dbUrl = dbUrl;
    }

    public void setDbUser(String dbUser) {
        this.dbUser = dbUser;
    }

    public void setDbPassword(String dbPassword) {
        this.dbPassword = dbPassword;
    }
}
