package main.java.models;

import lombok.Getter;

import java.util.Map;


@Getter
public class QueryResult {
    private final String query;
    private final Map<String, String> resultSet;

    public QueryResult(String query, Map<String, String> resultSet) {
        this.query = query;
        this.resultSet = resultSet;
    }
}
