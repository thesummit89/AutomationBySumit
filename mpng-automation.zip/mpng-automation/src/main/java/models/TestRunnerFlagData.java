package main.java.models;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class TestRunnerFlagData {
    private String testId;
    private String runMode;
    private String testDescription;
    private Map<String, String> testids;
    public String getTestId() {
        return testId;
    }
    public void setTestId(String testId) {
        this.testId = testId;
    }

    public void setTestids(Map<String, String> testids) {
        this.testids = testids;
    }

    public String getRunModee() {
        return runMode;
    }

    public void setRunModee(String runModee) {
        this.runMode = runModee;
    }

    public String getRunMode() {
        return runMode;
    }

    public String getTestDescription() {
        return testDescription;
    }

    public void setTestDescription(String testDescription) {
        this.testDescription = testDescription;
    }

    public Map<String, String> getTestids() {
        return testids;
    }

    public void setRunMode(String runMode) {
        this.runMode = runMode;
    }
}
