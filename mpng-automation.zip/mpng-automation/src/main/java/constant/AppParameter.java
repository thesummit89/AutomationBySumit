package main.java.constant;

import main.java.utility.DateUtil;
import main.java.utility.RandomGenerator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public final class AppParameter {

	private AppParameter() {
	}

	public static final String CURRENT_VALUE_DATE_INT_KEY = "$CURVALINTDATE";
	public static final String CURRENT_VALUE_DATE_ISO_KEY = "$CURVALDATE";
	public static final String CURRENT_VALUE_DATE_MSG_KEY = "$CURVALMSGDATE";
	public static final String CURRENT_VALUE_DATE_WEB_KEY = "$CURVALWEBDATE";
	public static final String UPCOMING_SATURDAY_DATE_INT = "$UPCOMING_SATURDAY_DATE_INT";
	public static final String UPCOMING_SATURDAY_DATE_ISO = "$UPCOMING_SATURDAY_DATE_ISO";
	public static final String UPCOMING_SATURDAY_DATE_MSG = "$UPCOMING_SATURDAY_DATE_MSG";

	public static final String CURRENT_VALUE_DATE_TIMESTAMP_KEY = "$CURVALTIMESTAMPDATE";
	private static final String EXTRA_DAYS = "(\\.((\\|\\|)?\\-?\\d*M?)+)?";
	public static final String UNIQUE_VALUE_KEY = "$UNIQUEVALUE";

	private static String currentValueDate = "";
	private static Date currentValueDateAsDate = new Date();
	public static final String NOT_SUPPORTED_PARAM_VALUE = "param_not_supported";

	public static void setCurrentValueDate(String currentValueDate) throws ParseException {
		AppParameter.currentValueDate = currentValueDate;
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		currentValueDateAsDate = format.parse(currentValueDate);
	}

	public static boolean isFieldValueContainsParameter(String fieldValue) {
		return fieldValue.contains(UNIQUE_VALUE_KEY) || fieldValue.contains(CURRENT_VALUE_DATE_INT_KEY)
				|| fieldValue.contains(CURRENT_VALUE_DATE_ISO_KEY) || fieldValue.contains(CURRENT_VALUE_DATE_MSG_KEY)
				|| fieldValue.contains(CURRENT_VALUE_DATE_TIMESTAMP_KEY) || fieldValue.contains(CURRENT_VALUE_DATE_WEB_KEY);
	}

	private static final Pattern PLACEHOLDER_REGEX = Pattern.compile("\\" + CURRENT_VALUE_DATE_INT_KEY + EXTRA_DAYS
			+ "|\\" + CURRENT_VALUE_DATE_ISO_KEY + EXTRA_DAYS + "|\\" + CURRENT_VALUE_DATE_MSG_KEY + EXTRA_DAYS + "|\\" + CURRENT_VALUE_DATE_WEB_KEY + EXTRA_DAYS + "|\\"
			+ CURRENT_VALUE_DATE_TIMESTAMP_KEY + EXTRA_DAYS + "|\\" + UNIQUE_VALUE_KEY);

	public static String replaceParameter(String fieldValue) {

		Matcher matcher = PLACEHOLDER_REGEX.matcher(fieldValue);
		Stream<MatchResult> matchResultList = matcher.results();
		List<String> parameters = matchResultList.map(MatchResult::group).collect(Collectors.toList());

		for (String parameter : parameters) {
			final String parameterValue = getValue(parameter);

			fieldValue = fieldValue.replace(parameter, parameterValue);
		}

		return fieldValue;
	}

	private static String addExtraDayMonth(String parameterName, String dateFormat, Date date) {
		SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		String extraDayMonth = parameterName.substring(parameterName.indexOf(".") + 1);
		String[] extraDayMonthArr = extraDayMonth.split("\\|\\|");

		Date futureDate = new Date(date.getTime());
		for (String extra : extraDayMonthArr) {
			if (extra.endsWith("M")) {
				int months = Integer.parseInt(extra.substring(0, extra.length() - 1));
				boolean isFuture = months > 0;
				futureDate = DateUtil.addMonths(futureDate, months);
				futureDate = checkDateFallOnWeekEnds(futureDate, isFuture);
			} else {
				int days = Integer.parseInt(extra);
				boolean isFuture = days > 0;
				futureDate = DateUtil.addDays(futureDate, days);
				futureDate = checkDateFallOnWeekEnds(futureDate, isFuture);
			}
		}

		return format.format(futureDate);

	}

	private static Date checkDateFallOnWeekEnds(Date date, boolean isFuture) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int weekDayIndex = calendar.get(Calendar.DAY_OF_WEEK);
		if (weekDayIndex == 1) { // Calendar.DAY_OF_WEEK regards 1 -> Sunday
			if (isFuture) {
				calendar.add(Calendar.DAY_OF_MONTH, 1);
			} else {
				calendar.add(Calendar.DAY_OF_MONTH, -2);
			}
			return calendar.getTime();
		}

		if (weekDayIndex == 7) { // Calendar.DAY_OF_WEEK regards 7 -> Saturday
			if (isFuture) {
				calendar.add(Calendar.DAY_OF_MONTH, 2);
			} else {
				calendar.add(Calendar.DAY_OF_MONTH, -1);
			}

			return calendar.getTime();
		}

		return date;
	}

	private static long addExtraDayMonth(String parameterName, Date date) {
		String extraDayMonth = parameterName.substring(parameterName.indexOf(".") + 1);
		String[] extraDayMonthArr = extraDayMonth.split("\\|\\|");

		Date futureDate = new Date(date.getTime());
		for (String extra : extraDayMonthArr) {
			if (extra.endsWith("M")) {
				int months = Integer.parseInt(extra.substring(0, extra.length() - 1));
				futureDate = DateUtil.addMonths(futureDate, months);
			} else {
				futureDate = DateUtil.addDays(futureDate, Integer.parseInt(extra));
			}
		}

		return futureDate.getTime();

	}

	private static Date getUpcomingSaturday() {
		Date date = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int weekDay = calendar.get(Calendar.DAY_OF_WEEK);
		calendar.add(Calendar.DAY_OF_MONTH, 7 - weekDay);

		return calendar.getTime();
	}

	public static String getValue(String parameterName) {
		if (parameterName.equals(UNIQUE_VALUE_KEY)) {
			return RandomGenerator.getTimestampString();
		} else if (parameterName.equals(CURRENT_VALUE_DATE_INT_KEY)) {
			return currentValueDate;
		} else if (parameterName.equals(CURRENT_VALUE_DATE_ISO_KEY)) {
			return DateUtil.getDatetimeAsISOString(currentValueDateAsDate);
		} else if (parameterName.equals(CURRENT_VALUE_DATE_MSG_KEY)) {
			SimpleDateFormat msgDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			return msgDateFormat.format(currentValueDateAsDate);
		} else if (parameterName.equals(CURRENT_VALUE_DATE_WEB_KEY)) {
			SimpleDateFormat msgDateFormat = new SimpleDateFormat("dd MMM yyyy");
			return msgDateFormat.format(currentValueDateAsDate);
		} else if (parameterName.equals(CURRENT_VALUE_DATE_TIMESTAMP_KEY)) {
			return String.valueOf(currentValueDateAsDate.getTime());
		} else if (parameterName.equals(UPCOMING_SATURDAY_DATE_INT)) {
			Date saturdayDate = getUpcomingSaturday();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
			return simpleDateFormat.format(saturdayDate);
		} else if (parameterName.equals(UPCOMING_SATURDAY_DATE_ISO)) {
			Date saturdayDate = getUpcomingSaturday();
			return DateUtil.getDatetimeAsISOString(saturdayDate);
		} else if (parameterName.equals(UPCOMING_SATURDAY_DATE_MSG)) {
			Date saturdayDate = getUpcomingSaturday();
			SimpleDateFormat msgDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			return msgDateFormat.format(saturdayDate);
		} else if (parameterName.startsWith(CURRENT_VALUE_DATE_INT_KEY)) {
			return addExtraDayMonth(parameterName, "yyyyMMdd", currentValueDateAsDate);
		} else if (parameterName.startsWith(CURRENT_VALUE_DATE_MSG_KEY)) {
			return addExtraDayMonth(parameterName, "yyyy-MM-dd", currentValueDateAsDate);
		} else if (parameterName.startsWith(CURRENT_VALUE_DATE_WEB_KEY)) {
			return addExtraDayMonth(parameterName, "dd MMM yyyy", currentValueDateAsDate);
		} else if (parameterName.startsWith(CURRENT_VALUE_DATE_ISO_KEY)) {
			Date futureDate = DateUtil.addDays(currentValueDateAsDate,
					Integer.parseInt(parameterName.substring(parameterName.indexOf(".") + 1)));
			return DateUtil.getDatetimeAsISOString(futureDate);
		} else if (parameterName.startsWith(CURRENT_VALUE_DATE_TIMESTAMP_KEY)) {
			return String.valueOf(addExtraDayMonth(parameterName, currentValueDateAsDate));
		} else {
			return NOT_SUPPORTED_PARAM_VALUE;
		}
	}
}
