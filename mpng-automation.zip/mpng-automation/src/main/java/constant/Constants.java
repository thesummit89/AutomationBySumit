package main.java.constant;

public final class Constants {
	public static String EXECUTION_REPORT_PATH, SCREENSHOT_PATH_FAIL, SCREENSHOT_PATH_PASS;
	public static final String CONFIG_PATH= System.getProperty("user.dir")+"\\resources\\config.properties";
	final public static String PROJECTPATH = System.getProperty("user.dir") + "/test-output/reports";
	final public static String DRIVER_PATH = "resources/chromeDriver/chromedriver.exe";
	final public static String BASE_URL = "http://192.168.9.134/";
	final public static String CBOP_BASE_URL = "http://192.168.9.220/";
	final public static String FRONTEND_PORT = "";
	public static final int DB_OFFSET_VARIATION_SECONDS = 2;
	public static final int DRIVER_IMPLICIT_WAIT_MILLIS = 10000;
}
