package main.java.utility;


import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;

import java.io.File;
import java.util.Map;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

public class ApiUtils {

//    private static String getLoginToken(String userName, String password) {
//        baseURI = Constants.BASE_URL+Constants.BACKEND_PORT;
//        RequestSpecification request = given();
//        JSONObject requestParams = new JSONObject();
//        requestParams.put("userName", userName);
//        requestParams.put("password", password);
//        request.header("Content-Type", "application/json");
//        request.body(requestParams.toJSONString());
//
//        Response response = request.post("/api/internal/public/login");
//        // System.out.println("The response received: " + response.getBody().asString());
//
//        // Get the JsonPath object instance from the Response interface
//        JsonPath jsonPathEvaluator = response.jsonPath();
//
//        // Then simply query the JsonPath object to get a String value of the node
//        String value = jsonPathEvaluator.get("token");
//
//        return value;
//
//    }
//
//    public static RequestSpecification getRequest(String baseURL, String loginEndpoint, String userName, String password) {
//        String loginToken = getLoginToken(userName, password);
//
//        RequestSpecification request = given();
//        request.header("Content-Type", "application/json");
//        request.header("Authorization", "Bearer " + loginToken);
//        return request;
//    }
//
//    public static void uploadFile(Map<String, String> options, String testFolderPath) {
//        File file = new File(testFolderPath + "/input/" + options.get("fileName"));
//
//        // build request
//        RequestSpecification request = getRequest(options.get("baseURL"), );
//        request.contentType("multipart/form-data")
//                .multiPart("file", file,"text/plain");
//
//        // send request and save as response
//        Response response = request.post(endpoint);
//        System.out.println("The response received: " + response.getBody().asString());
//    }
//
//    public static void approveFile(String endpoint, String fileName) {
//        // build request
//        RequestSpecification request = ApiUtils.getRequest(Constants.DEFAULT_CHECKER_USER); // login as adminuser2
//        JSONObject requestParams = new JSONObject();
//        requestParams.put("id", fileName);
//        requestParams.put("status", "APPROVED");
//        requestParams.put("remarks", null);
//        request.body(requestParams.toJSONString());
//
//        // send request and save as response
//        Response response = request.post(endpoint);
//
//    }
}
