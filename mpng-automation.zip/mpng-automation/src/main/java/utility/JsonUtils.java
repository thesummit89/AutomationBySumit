package main.java.utility;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import main.java.models.TechStep;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class JsonUtils {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static <T> T fromJsonFile(String filePath, Class<T> clazz) throws IOException {
        return objectMapper.readValue(new File(filePath), clazz);
    }

    public static <T> List<T> fromJsonFileToList(String filePath, TypeReference<List<T>> typeReference) throws IOException {
        return  objectMapper.readValue(new File(filePath), typeReference);
    }

    public static Map<String, Map<String, Object>> fromJsonFileToMap(String filePath) throws IOException {
        return objectMapper.readValue(new File(filePath), new TypeReference<Map<String, Map<String, Object>>>() {});
    }

    public static void saveTechStepsToJsonFile(List<TechStep> techSteps, String filePath) {
        try {
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(filePath), techSteps);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}