package main.java.utility;

//import com.google.protobuf.compiler.PluginProtos;
import main.java.constant.AppParameter;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
public class CsvUtils {

    public static Map<String, String> readCsvToMap(String csvFilePath) throws IOException {

        List<String> percentage =
                Files.lines(Paths.get(
                        csvFilePath))
                        .collect(Collectors.toCollection(ArrayList::new));
        //extract only the top row containing headers
        List<String> topRow = Arrays.stream(percentage.get(0).split(",")).collect(Collectors.toList());
        List<String> dataRows = Arrays.stream(percentage.get(1).split(",")).collect(Collectors.toList());
          int topRowSize=topRow.size();
        int dataRowSize=dataRows.size();
        if (topRow.size() == dataRows.size()) {
            Map<String, String> dataMap = new LinkedHashMap<String, String>();
            for (int i = 0; i < topRow.size(); i++) {
                String rowValue = dataRows.get(i);
                // Check for any placeholders eg. $CURVALWEBDATE and replace them
                if (AppParameter.isFieldValueContainsParameter(rowValue)) {
                    rowValue = AppParameter.replaceParameter(rowValue);
                }
                dataMap.put(topRow.get(i), rowValue);
            }
            return dataMap;
        }

        throw new IOException("CSV cannot be converted to Map.");
    }

    public static List<Map<String, String>> readCsvToListOfMap(String csvFilePath) throws IOException {
        List<Map<String, String>> data = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            String[] headers = null;

            while((line = br.readLine()) != null) {
                String[] values = line.split(",");

                // First line is header
                if (headers == null) {
                    headers = values;
                } else {
                    Map<String, String> recordMap = new LinkedHashMap<>();
                    for (int i = 0; i < headers.length; i++) {
                        recordMap.put(headers[i], values[i]);
                    }
                    data.add(recordMap);
                }
            }
            return data;
        }
    }

    public static void writeResultsToCsv(List<Map<String, String>> data, String filePath) throws IOException {
        try (FileWriter csvWriter = new FileWriter(filePath)) {
            // Write header
            csvWriter.append("Record No,Field Name,Expected,Actual,Pass/Fail\n");

            for (Map<String, String> rowData : data) {
                csvWriter.append(rowData.get("Record No")).append(",")
                        .append(rowData.get("Field Name")).append(",")
                        .append(rowData.get("Expected")).append(",")
                        .append(rowData.get("Actual")).append(",")
                        .append(rowData.get("Pass/Fail")).append("\n");
            }
        }
    }
}
