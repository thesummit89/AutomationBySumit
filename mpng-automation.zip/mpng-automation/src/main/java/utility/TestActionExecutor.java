package main.java.utility;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.fasterxml.jackson.core.type.TypeReference;
import main.java.models.TechStep;

import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.*;

public class TestActionExecutor {
    private WebDriver driver;
    private WebDriverUtils webDriverUtil;
    private ExtentTest extentTest;
    private ApiUtils apiUtil;
    private DbUtils dbUtil;
    private List<String> tables = new ArrayList<>();

    public TestActionExecutor(WebDriver driver, ExtentTest extentTest) {
        this.driver = driver;
        this.webDriverUtil = new WebDriverUtils(driver);
        this.extentTest = extentTest;
        this.apiUtil = new ApiUtils();
        this.dbUtil = new DbUtils();
    }

    public List<TechStep> executeAction(String actionType, Map<String, String> data, String testFolderPath, String now) throws IOException, SQLException {
        String configDirectory = "RTGSSSSTestCases/modules";

        // scans through modules folder for the correct config file
        Path configFilePath = FileUtils.getConfigPath(actionType, "json", configDirectory);

        TypeReference listTypeReference = new TypeReference<List<TechStep>>() {
        };
        List<TechStep> steps = JsonUtils.fromJsonFileToList(configFilePath.toString(), listTypeReference);
        Collections.sort(steps, Comparator.comparingInt(TechStep::getSequence));


        for (TechStep step : steps) {
            if (data != null) { // passes the info from input into the techstep
                for (Map.Entry<String, String> entry : data.entrySet()) {
                    if (step.getTextBoxValue() != null) {
                        if (step.getTextBoxValue().equalsIgnoreCase("{" + entry.getKey() + "}")) {
                            step.setTextBoxValue(entry.getValue());
                        }
                    }
                    if (step.getOptions() != null) {
                        for (Map.Entry<String, String> option : step.getOptions().entrySet()) {
                            if (option.getValue().equalsIgnoreCase("{" + entry.getKey() + "}")) {
                                option.setValue(entry.getValue());
                            }
                        }
                    }
                }
            }

            if (step.getWait() != null) {
                if (step.getWait() > 0) {
                    try {
                        Thread.sleep(step.getWait());
                    } catch (InterruptedException e) {
//                        e.printStackTrace();
                        extentTest.log(Status.WARNING, "Interrupted during wait: " + e.getMessage());
                    }
                }
            }

            if (step.getLog()) {
                // Implement logging logic here
                System.out.println("Started: " + step);
                extentTest.info("Started: " + step);
            }

            switch (step.getCategory()) {
                case "WEB":
                    executeWebStep(step, testFolderPath, configDirectory);
                    break;
                case "API":
                    executeApiStep(step, testFolderPath);
                    break;
                case "SQL":
                    executeSqlStep(step, testFolderPath, now);
                    break;
                // add more categories if needed. Eg VERIFY
                default:
                    throw new IllegalArgumentException("Unknown action category: " + step.getCategory());
            }

            if (step.getLog()) {
                // Implement logging logic here
                System.out.println("Finished: " + step);
                extentTest.info("Finished: " + step, ScreenshotUtil.capture(driver, testFolderPath+"/report/"+now+"/screenshots/"+System.currentTimeMillis()+".png"));
            }
        }

        // return the steps back to Base Test to build input text file
        return steps;
    }


    private void executeWebStep(TechStep step, String testFolderPath, String moduleFolderPath) throws IOException {
        switch (step.getType()) {
            case "url":
                webDriverUtil.goToUrl(step.getUrl());
//                System.out.println(driver.getCurrentUrl());
                break;
            case "input":
//                System.out.println(step.getElementId() + ", " + step.getTextBoxValue());
                webDriverUtil.inputText(step.getElementId(), step.getTextBoxValue());
                break;
            case "click":
//                System.out.println(step.getElementId() + ", click");
                webDriverUtil.click(step.getElementId());
                break;
            case "form_fill":
                webDriverUtil.formFill(step.getOptions(), testFolderPath, moduleFolderPath);
                break;
            case "key_value_verification":
                tables = webDriverUtil.keyValueVerification(step.getOptions(), testFolderPath, moduleFolderPath);
                for(String table : tables) {
                    extentTest.log(Status.INFO, "Key Value verification");
                    extentTest.log(Status.INFO, MarkupHelper.toTable(table));
                }
                break;
            case "table_verification":
                tables = webDriverUtil.tableVerification(step.getOptions(), testFolderPath);
                for(String table : tables) {
                    extentTest.log(Status.INFO, "Table verification");
                    extentTest.log(Status.INFO, MarkupHelper.toTable(table));
                }
                break;
            case "input_file":
                webDriverUtil.inputFile(step.getElementId(), step.getTextBoxValue(), testFolderPath);
                break;
            case "check_click":
                webDriverUtil.checkClick(step.getElementId());
                break;

            // add more types as needed
            default:
                throw new IllegalArgumentException("Unknown web step type: " + step.getType());
        }
    }

    private void executeApiStep(TechStep step, String testFolderPath) {
        switch (step.getType()) {
            case "upload_file":
//                apiUtil.uploadFile(step.getOptions(), testFolderPath);
                break;
            case "approve":
//                apiUtil.approve(step.getOptions().get("endpoint"), step.getOptions().get("fileName"));
                break;
            // add more types as needed
            default:
                throw new IllegalArgumentException("Unknown API step type: " + step.getType());
        }
    }

    private void executeSqlStep(TechStep step, String testFolderPath, String now) throws IOException, SQLException {
        switch (step.getType()) {
            case "execute_file":
                dbUtil.executeFile(step.getOptions(), testFolderPath);
                System.out.println(dbUtil.calculateOffset());
                break;
            case "query_to_csv":
                tables = dbUtil.queryToCsv(step.getOptions(), testFolderPath, now);
                for(String table : tables) {
                    extentTest.log(Status.INFO, MarkupHelper.toTable(table));
                }
                break;
            // add more types as needed
            default:
                throw new IllegalArgumentException("Unknown SQL step type: " + step.getType());
        }
    }
}
