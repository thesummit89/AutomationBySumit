package main.java.utility;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import main.java.constant.Constants;
import main.java.models.QueryResult;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import main.java.models.SqlCreds;

import static main.java.utility.DateUtil.toDateTimeString;

public class DbUtils {
    // Connection object
    static Connection con = null;
    // Statement object
    private static Statement stmt;
    // Database URL
    public static String dbUrl = null;
    // Database username
    public static String dbUser = null;
    // Database password
    public static String dbPassword = null;

    private static List<String> resultSetArray;

    private static String separator = ",";

    private static String tableName = null;

    public static void getConnection(String applicationId) throws Exception {
        try {
            // Get SQL credentials from sql_connections.json
            String sqlConnectionsFilePath = "RTGSSSSTestCases/endpoints/data-sources.json";
            List<SqlCreds> sqlCredsList = new ObjectMapper().convertValue(JsonUtils.fromJsonFile(sqlConnectionsFilePath, List.class), new TypeReference<List<SqlCreds>>() {});

            // Pass in credentials into setup to set the connection
            SqlCreds sqlCreds = sqlCredsList.stream().filter(e->e.getApplicationId().equals(applicationId)).findAny().orElse(null);
            dbUrl = sqlCreds.getDbUrl();
            dbUser = sqlCreds.getDbUser();
            dbPassword = sqlCreds.getDbPassword();

            // Database connection
            String dbClass = "com.mysql.cj.jdbc.Driver";
            Class.forName(dbClass).newInstance();
            // Get connection to DB
            con = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            // Statement object to send the SQL statement to the Database
            stmt = con.createStatement();
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

//    public static void getActualDataToCsv(String tableName, String whereClause, String startTime, String testId) {
//        try {
//            getConnection();
//            resultSetArray = new ArrayList<>();
//            String endTime = toDateTimeString(LocalDateTime.now(), "yyyy-MM-dd HH:mm:ss");
//            whereClause = whereClause != "" ? whereClause + "and " : whereClause;
//            startTime = startTime != null ? ">= '"+startTime+"'" : "is "+null;
//            String query = "select * from "+tableName+" where "+whereClause+"modified_timestamp "+startTime+"";
////            String query = "select * from "+tableName+" where "+whereClause+"modified_timestamp BETWEEN '"+startTime+
////                    "' and '"+endTime+"'";
//            System.out.println(query);
//            fetchDataFromDatabase(query);
//            printToCsv(resultSetArray, testId);
//        }
//        catch (Exception e){
//            throw new RuntimeException(e);
//        }
//    }

    private static String fetchDataFromDatabase (String selectQuery) throws Exception {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(selectQuery);
            ResultSetMetaData rsmd = rs.getMetaData();
            int numCols = rsmd.getColumnCount();
            tableName = rsmd.getTableName(1); // used when saving csv filename


            // Get table headers
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 1; i <= numCols; i++) {
                stringBuilder.append(String.format(String.valueOf(rsmd.getColumnLabel(i))) + separator);
            }

            resultSetArray.add(stringBuilder.toString().substring(0, stringBuilder.length() - 1)); // remove the last ","

            // Get table body
            while(rs.next()) {
                StringBuilder sb = new StringBuilder();

                for (int i = 1; i <= numCols; i++) {
                    sb.append(String.valueOf(rs.getString(i)) + separator);
                }
                resultSetArray.add(sb.toString().substring(0, sb.length() - 1)); // remove the last ","
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return tableName; // sets tableName to null making csv file output as null
    }

//    private static void printToCsv (List<String> resultArray, String testId) throws Exception{
//        String now = toDateTimeString(LocalDateTime.now(), "yyyyMMddHHmm");
//
//        testId = testId != null ? "/"+testId : "";
//
//        String folderPath = "./tests/test_case"+testId+"/report/"+now+"/";
//        File csvOutputFile = new File(folderPath);
//        csvOutputFile.mkdirs(); // create folders based on now
//        csvOutputFile = new File(folderPath + tableName +"_"+ now +".csv");
//        FileWriter fileWriter = new FileWriter(csvOutputFile, false);
//
//        for(String mapping : resultArray) {
//            fileWriter.write(mapping + "\n");
//        }
//
//        fileWriter.close();
//
//    }

    public static void executeSql(String sqlFilePath) {
        try{
            SQLExecutor executor = new SQLExecutor(dbUrl, dbUser, dbPassword);
            executor.executeFile(sqlFilePath);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

//    public static String findIdByQuery(String query) {
//        String result = null;
//        try{
//            getConnection();
//            ResultSet rs = stmt.executeQuery(query);
//            result = rs.getObject(1).toString();
//        }
//        catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//        return result;
//    }

    public int calculateOffset (){
        int offset = 0;

        try {
            // Get connection to DB
            con = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);

            ResultSet rs = stmt.executeQuery("SELECT CURRENT_TIMESTAMP");
            rs.first();

            String localNow = toDateTimeString(LocalDateTime.now(), "yyyy-MM-dd HH:mm:ss");
            String dbNow = rs.getString(1);

            offset = DateUtil.findDifference(dbNow, localNow) - Constants.DB_OFFSET_VARIATION_SECONDS;
            System.out.println("DB is behind local time by: "+offset+" seconds");

            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return offset;
    }

//    public static QueryResult queryDatabase(String tableName, Map<String,String> conditions) throws SQLException {
//        Map<String, String> results = new HashMap<>();
//        StringBuilder queryBuilder = new StringBuilder("SELECT * FROM " + tableName + " WHERE ");
//
//        conditions.forEach((field, value) -> {
//            if (value == null || value.contains("null")) {
//                queryBuilder.append(field).append(" IS NULL AND ");
//            } else {
//                queryBuilder.append(field).append(" LIKE '").append(value).append("' AND ");
//            }
//        });
//
//
//        String query = queryBuilder.substring(0, queryBuilder.length() - 5); // remove the last " AND "
//
//        try {
//            getConnection();
//            ResultSet resultSet = stmt.executeQuery(query);
//            System.out.println("Querying: " + query);
//
//            ResultSetMetaData metaData = resultSet.getMetaData();
//            int columnCount = metaData.getColumnCount();
//
//            while (resultSet.next()) {
//                for (int i = 1; i <= columnCount; i++) {
//                    String columnName = metaData.getColumnName(i);
//                    results.put(columnName, resultSet.getString(columnName));
//                }
//            }
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//        return new QueryResult(query, results);
//    }

    public void executeFile(Map<String, String> options, String testFolderPath) throws IOException, SQLException {
        // Get SQL credentials from sql_connections.json
        String sqlConnectionsFilePath = "RTGSSSSTestCases/endpoints/data-sources.json";
        List<SqlCreds> sqlCredsList = new ObjectMapper().convertValue(JsonUtils.fromJsonFile(sqlConnectionsFilePath, List.class), new TypeReference<List<SqlCreds>>() {});

        // Pass in credentials into setup to set the connection
//        SqlCreds sqlCreds = sqlCredsList.stream().filter(e->e.getApplicationId().equals(options.get("applicationId"))).findAny().orElse(null);
//        dbUrl = sqlCreds.getDbUrl();
//        dbUser = sqlCreds.getDbUser();
//        dbPassword = sqlCreds.getDbPassword();

        // Get connection
        try {
            getConnection(options.get("applicationId"));

            // Get file path to clear_data.sql
            String sqlFileName = options.get("sqlFileName");
            String sqlFilePath = testFolderPath + "/input/" + sqlFileName;

            // Execute SQL query
            executeSql(sqlFilePath);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Requires fields to start with "expectedFileName_" and "actualDataCriteria_" to get the table name, fields, where clause
    public List<String> queryToCsv(Map<String, String> options, String testFolderPath, String now) throws SQLException, IOException {
        List<String> tables = new ArrayList<>();
        for (int i = 1; i < options.size(); i++) {
            String table = "";
            if (options.get("expectedFileName_"+i) != null) {
                String csvFileName = options.get("expectedFileName_"+i);
                String tableName = options.get("expectedFileName_"+i).split("\\.")[0];
                String whereClause = options.get("actualDataCriteria_"+i);

                // Get table expected data as map
                String csvFilePath = testFolderPath+"/expected/"+csvFileName;
                List<Map<String, String>> expectedDataList = CsvUtils.readCsvToListOfMap(csvFilePath);

                // Get headers from expectedData
                List<String> headers = new ArrayList<>();
                for (String header : expectedDataList.get(0).keySet()){
                    headers.add("`"+header+"`");
                }

                // Build query with headers, table name and where clause
                String query = "SELECT ";

                query += String.join(", ", headers);

                // Add where clause to query
                query += whereClause != "" ? " FROM " + tableName + " WHERE " + whereClause :  " FROM " + tableName;
//                query += " FROM " + tableName + " WHERE " + whereClause;

                System.out.println(query);

                try {
                    getConnection(options.get("applicationId"));

                    resultSetArray = new ArrayList<>();

                    fetchDataFromDatabase(query);

                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

                // Determine output CSV file path
                String reportFolderPath = testFolderPath + "/report/" + now +"/";
                String outputFilePath = reportFolderPath + "actual_" + tableName + ".csv";
                File csvOutputFile = new File(outputFilePath);
                FileWriter fileWriter = new FileWriter(csvOutputFile, false);

                for(String mapping : resultSetArray) {
                    fileWriter.write(mapping + "\n");
                }

                fileWriter.close();

                // Compare expected and actual
                // Get actual to same type of List<Map<String, String>> as expectedDataList
                List<Map<String, String>> actualDataList = CsvUtils.readCsvToListOfMap(outputFilePath);

                List<Map<String,String>> comparisonResults = ResultsComparator.compareListOfMaps(expectedDataList, actualDataList);

                // Write results to CSV
                CsvUtils.writeResultsToCsv(comparisonResults, reportFolderPath+"result_"+tableName+".csv");

                HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 3, 5);
                htmlBuilder.addTableHeader("Table =>",tableName,"","","");
                htmlBuilder.addTableHeader("Record ID", "Field Name","Expected Data","Actual Data","Pass/Fail");

                for (Map<String, String> result : comparisonResults) {
                    htmlBuilder.addRowValues(result.get("Record No"), result.get("Field Name"),result.get("Expected"),result.get("Actual"),result.get("Pass/Fail"));
                }
                table = htmlBuilder.build();
                tables.add(table);
            }
        }
        return tables;
        // return List<String> queries;
    }
}
