package main.java.utility;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.model.Media;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

public class ScreenshotUtil {
    public static Media capture (WebDriver driver, String filePath) throws IOException {
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File dest = new File(filePath);
        String destFilePath = dest.getAbsolutePath();
        FileUtils.copyFile(scrFile, dest);

        return MediaEntityBuilder.createScreenCaptureFromPath(destFilePath).build();
    }
}
