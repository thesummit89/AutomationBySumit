package main.java.utility;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ResultsComparator {

    // compare 2 maps return list of comparison results
    public static List<Map<String, String>> compareMaps (Map<String, String> expectedDataMap, Map<String, String> actualDataMap) {
        List<Map<String, String>> comparisonResults = new ArrayList<>();
//        comparisonResults.add(new String[]{"Record No", "Field Name", "Expected", "Actual", "Pass/Fail"});

        int recordNo = 1;

        for (String key : expectedDataMap.keySet()) {
            String expectedValue = expectedDataMap.get(key);
            String actualValue = actualDataMap.get(key);
            String passFail = expectedValue.equals(actualValue) ? "Pass" : "Fail";
            Map<String, String> result = new LinkedHashMap<>();
            result.put("Record No", String.valueOf(recordNo++));
            result.put("Field Name", key);
            result.put("Expected", expectedValue);
            result.put("Actual", actualValue);
            result.put("Pass/Fail", passFail);
            comparisonResults.add(result);
        }

        return comparisonResults;
    }

        // compare 2 list of maps return list of comparison results
    public static List<Map<String, String>> compareListOfMaps (List<Map<String, String>> expectedDataList, List<Map<String, String>> actualDataList) {
        List<Map<String, String>> comparisonResults = new ArrayList<>();
//        comparisonResults.add(new String[]{"Record No", "Field Name", "Expected", "Actual", "Pass/Fail"});

        int recordNo = 1;

        int maxSize = Math.max(expectedDataList.size(), actualDataList.size());

        for (int i = 0; i < maxSize; i++) {
            Map<String, String> expectedData = i < expectedDataList.size() ? expectedDataList.get(i) : null;
            Map<String, String> actualData = i < actualDataList.size() ? actualDataList.get(i) : null;

            if (expectedData != null && actualData != null) {
                for (String key : expectedData.keySet()) {
                    String expectedValue = expectedData.get(key);
                    String actualValue = actualData.get(key);
                    String passFail = (expectedValue.equals(actualValue)) ? "Pass" : "Fail";
                    Map<String, String> result = new LinkedHashMap<>();
                    result.put("Record No", String.valueOf(recordNo));
                    result.put("Field Name", key);
                    result.put("Expected", expectedValue);
                    result.put("Actual", actualValue);
                    result.put("Pass/Fail", passFail);
                    comparisonResults.add(result);
                }
                for (String key : actualData.keySet()) {
                    if (!expectedData.containsKey(key)) {
                        Map<String, String> result = new LinkedHashMap<>();
                        result.put("Record No", String.valueOf(recordNo));
                        result.put("Field Name", key);
                        result.put("Expected", "N/A");
                        result.put("Actual", actualData.get(key));
                        result.put("Pass/Fail", "Fail");
                        comparisonResults.add(result);
                    }
                }
            } else if (expectedData != null) {
                for (String key : expectedData.keySet()) {
                    Map<String, String> result = new LinkedHashMap<>();
                    result.put("Record No", String.valueOf(recordNo));
                    result.put("Field Name", key);
                    result.put("Expected", expectedData.get(key));
                    result.put("Actual", "N/A");
                    result.put("Pass/Fail", "Fail");
                    comparisonResults.add(result);
                }
            } else {
                for (String key : actualData.keySet()) {
                    Map<String, String> result = new LinkedHashMap<>();
                    result.put("Record No", String.valueOf(recordNo));
                    result.put("Field Name", key);
                    result.put("Expected", "N/A");
                    result.put("Actual", actualData.get(key));
                    result.put("Pass/Fail", "Fail");
                    comparisonResults.add(result);
                }
            }

            recordNo++;
        }

        return comparisonResults;
    }
}
