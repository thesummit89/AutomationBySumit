package main.java.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public final class DateUtil {
	private DateUtil() {
		
	}
	
	public static String getDatetimeAsISOString(Date date) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		return df.format(date) + "Z";
	}
	
	public static String getCurrentDateAsyyyyMMddWithHyphen() {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		return df.format(new Date());
	}
	
	public static Date addDays(Date date, int days) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DATE, days);
		return calendar.getTime();
	}
	
	public static Date addMonths(Date date, int months) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, months);
		return calendar.getTime();
	}

	public static String toDateTimeString(LocalDateTime localDateTime, String pattern) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		return localDateTime.format(formatter);
	}

	public static int findDifference(String startDate, String endDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		int differenceInSeconds = 0;

		try {
			Date d1 = sdf.parse(startDate);
			Date d2 = sdf.parse(endDate);

			long differenceInTime = d2.getTime() - d1.getTime();

			differenceInSeconds = Math.toIntExact((differenceInTime/1000) % 60);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return differenceInSeconds;
	}
}
