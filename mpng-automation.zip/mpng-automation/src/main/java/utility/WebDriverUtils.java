package main.java.utility;

import main.java.constant.Constants;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import static main.java.utility.FileUtils.getConfigPath;

public class WebDriverUtils {
    private WebDriver driver;

    public WebDriverUtils(WebDriver driver) {
        this.driver = driver;
    }

    public void inputText(String elementId, String value) {
        WebElement element = getWebElement(elementId);
        element.clear();
        element.sendKeys(value);
    }

    public void inputFile(String elementId, String value, String testFolderPath) {
        WebElement element = getWebElement(elementId);
        String filePath = testFolderPath + "/input/" + value;

        // Read through input file, replace all placeholders, hash and write back to new or same file path?

        element.sendKeys(new File(filePath).getAbsolutePath());
    }

    public void dateInputText(String elementId, String value) {
        WebElement element = getWebElement(elementId);
        element.clear();
        element.sendKeys(value);
        element.sendKeys(Keys.RETURN);
        element.sendKeys(Keys.TAB);
    }

    public void click(String elementId) {
        WebElement element = getWebElement(elementId);
        element.click();
    }

    public void checkClick(String elementId) {
        if (checkWebElement(elementId)) {
            click(elementId);
        }
    }


    public void SelectUlDrpDwnListItem(String elementid, String listitem) {
        //By element is the xpath as the list items dont have id fields
        List<WebElement> allOptions= driver.findElements(By.xpath(elementid));

        for(int i=0; i<allOptions.size(); i++) {

            if(allOptions.get(i).getText().contains(listitem)) {
                allOptions.get(i).click();
                break;
            }
        }

    }

    public void goToUrl(String url) {
        driver.navigate().to(url);
//        driver.get(url);
    }

    public void getwebtablecelldata(String yourTableId, String headerName){
        // Locate the table
        WebElement table = driver.findElement(By.id(yourTableId));

// Get all header elements
        List<WebElement> headers = table.findElements(By.tagName("th"));
        int headerIndex = -1;

// Find the index of the header
        for (int i = 0; i < headers.size(); i++) {
            if (headers.get(i).getText().equals(headerName)) {
                headerIndex = i;
                break;
            }
        }

// Check if the header is found
        if (headerIndex == -1) {
            throw new RuntimeException("Header not found");
        }

// Iterate through each row and get the cell value based on header index
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row : rows) {
            List<WebElement> cells = row.findElements(By.tagName("td"));
            String cellValue = cells.get(headerIndex).getText();
            // Now you have the cell value, you can do something with it
            System.out.println(cellValue);
        }
    }

    public void formFill(Map<String, String> options, String testFolderPath, String moduleFolderPath) throws IOException {
        // Get csv file path for input
        String inputFileName = options.get("inputFileName");
        String inputFilePath = testFolderPath + "/input/" + inputFileName;

        // Get csv file path for elementType
        String[] parts = options.get("elementTypeFileName").split("\\.", 2);
        String elementTypeFileName = parts[0];
        String elementTypeFileExtension = parts[1];
        String configFilePath = getConfigPath(elementTypeFileName, elementTypeFileExtension, moduleFolderPath).toString();

        // Get each csv file into different lists/maps
        Map<String, String> inputMap = CsvUtils.readCsvToMap(inputFilePath);
        Map<String, String> elementTypeMap = CsvUtils.readCsvToMap(configFilePath);

        // Check for template input file
        String templateFileName;
        if (options.get("templateFileName") != null) {
            templateFileName = options.get("templateFileName");
            String templateFilePath = "RTGSSSSTestCases/dataTemplate/" + templateFileName;
            Map<String, String> templateMap = CsvUtils.readCsvToMap(templateFilePath);

            // Merge input into template
            inputMap = Merger.mergeInputDataIntoDataTemplate(templateMap, inputMap);
        }

        // Loop through each list/map
        // Assumes the columns in the input and elementType are the same size
        for (Map.Entry<String, String> input : inputMap.entrySet()) {
            String elementId = input.getKey(); // get the elementId
            String inputValue = input.getValue(); // get the value from input
            String elementType = elementTypeMap.get(input.getKey()); // get the value from elementType

            System.out.println("elementId: " + elementId + ", inputValue: " + inputValue + ", elementType: " + elementType);
            // handle logic of web element

            switch (elementType) {
                case "textbox":
                    inputText(elementId, inputValue);
                    break;
                case "btn":
                    click(elementId);
                    break;
                case "ulselect":
                    SelectUlDrpDwnListItem(elementId,inputValue);
                    break;
                case "datetextbox":
                    dateInputText(elementId, inputValue);
                    break;

                // add more types here. eg. date picker / radio button
                default:
                    throw new IllegalArgumentException("Unknown element type: " + elementType);
            }

        }
    }

    // Add other WebDriver related utilities as needed

    public List<String> keyValueVerification(Map<String, String> options, String testFolderPath, String moduleFolderPath) throws IOException {
        List<String> tables = new ArrayList<>();

        WebElement actualElement;
        String elementVal;
         Map<String, String> actualdataMap = new LinkedHashMap<String, String>();

        // Get csv file path for elementType
        String[] parts = options.get("elementTypeFileName").split("\\.", 2);
        String elementTypeFileName = parts[0];
        String elementTypeFileExtension = parts[1];
        String elementFilePath = getConfigPath(elementTypeFileName, elementTypeFileExtension, moduleFolderPath).toString();


        // get  review screen element csv file path and call csv util to get a map
        Map<String, String> dataMap = CsvUtils.readCsvToMap(elementFilePath);

        // fetch element from review screen map and fetch element from review screen and create actual data map

        for(Map.Entry m : dataMap.entrySet()){

            try{
                actualElement=driver.findElement(By.xpath(m.getValue().toString()));
                elementVal=actualElement.getText();
                actualdataMap.put(m.getKey().toString(),elementVal);
            } catch (NoSuchElementException e) {

                elementVal = "ElementNotFound";
                actualdataMap.put(m.getKey().toString(),elementVal);
            }
        }

        // get  review screen expected csv file path and call csv util to get a expected data map
        String reviewExpectedfilename = options.get("expectedFileName");
        String reviewExpectedFilePath = testFolderPath + "/expected/" + reviewExpectedfilename;
        Map<String, String> expectedDataMap=CsvUtils.readCsvToMap(reviewExpectedFilePath);
        // Compare two map

        Assert.assertEquals(expectedDataMap,actualdataMap);

        HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 2, 5);
        htmlBuilder.addTableHeader("Record ID", "Field Name","Expected Data","Actual Data","Pass/Fail");

        List<Map<String, String>> comparisonResults = ResultsComparator.compareMaps(expectedDataMap, actualdataMap);

        for(Map<String, String> result : comparisonResults) {
            htmlBuilder.addRowValues(result.get("Record No"), result.get("Field Name"),result.get("Expected"),result.get("Actual"),result.get("Pass/Fail"));
        }

        String table = htmlBuilder.build();
        tables.add(table);


        return tables;

    }

    public List<String> tableVerification(Map<String, String> options, String testFolderPath) throws IOException {
        List<String> tables = new ArrayList<>();

        // Get table ID and expected csv file
        String elementVal;
        Map<String, String> actualdataMap = new LinkedHashMap<String, String>();
        String[] parts = options.get("expectedFileName").split("\\.", 2);
        String elementTypeFileName = parts[0];
        String elementTypeFileExtension = parts[1];
        String elementFilePath = getConfigPath(elementTypeFileName, elementTypeFileExtension, testFolderPath+"/expected").toString();

        // Generate expected data map from expected csv file

        Map<String, String> expectedDataMap = new LinkedHashMap<String, String>();
        List<String> percentage =
                Files.lines(Paths.get(
                                elementFilePath))
                        .collect(Collectors.toCollection(ArrayList::new));

        List<String> topRow = Arrays.stream(percentage.get(0).split(",")).collect(Collectors.toList());
        List<String> dataRows = Arrays.stream(percentage.get(1).split(",")).collect(Collectors.toList());
        int topRowSize = topRow.size();
        int dataRowSize = dataRows.size();

        if (topRowSize == dataRowSize) {

            for (int i = 0; i < topRow.size(); i++) {
                try {
                    WebElement actualElement = driver.findElement(By.xpath(topRow.get(i)));

                    elementVal = actualElement.getText();


                    expectedDataMap.put(elementVal, dataRows.get(i));
                } catch (NoSuchElementException e) {

                    elementVal = "ElementNotFound";
                    expectedDataMap.put(elementVal, dataRows.get(i));
                }

            }

        }

        // fetch table details with the table ID

        String tableID=options.get("tableId");
        String tableXpathFirstPart="//*[@id='";
        String tableXpathSecondPart="']//thead//tr/th";
        String tableXpathThirdPart="']//tbody/tr";

        String finalTableHeaderXpath=tableXpathFirstPart+tableID+tableXpathSecondPart;
        String finalTableRowXpath=tableXpathFirstPart+tableID+tableXpathThirdPart;

        // Get the col and row count from the table

        int Col_count = driver.findElements(By.xpath(finalTableHeaderXpath)).size();
        int Row_count = driver.findElements(By.xpath(finalTableRowXpath)).size();

        // Build the table row header and row data xpath with help of index

        String headfirst_part = "//*[@id='result_table']/thead/tr/th[";
        String headSecond_part = "]";
        String headerFinal;

        String first_part = "//*[@id='result_table']/tbody/tr[";
        String second_part = "]/td[";
        String third_part = "]";

        int listCount = topRow.size();

        for (int i = 1; i < Row_count; i++) {


            for (int j=1; j<=Col_count; j++){

                headerFinal=headfirst_part+j+headSecond_part;
                String HeaderVal = driver.findElement(By.xpath(headerFinal)).getText().trim();

                for (int k = 0; k < listCount; k++) {

                    String listEle = topRow.get(k);
                    String header_data = driver.findElement(By.xpath(listEle)).getText();


                    if (HeaderVal.equals(header_data)) {

                        for (Map.Entry m : expectedDataMap.entrySet()) {
                            String MapVal = m.getKey().toString().trim();

                            if (HeaderVal.equals(MapVal)) {

                                try{

                                    String final_xpath1 = first_part + i + second_part + j + third_part;

                                    String Table_data = driver.findElement(By.xpath(final_xpath1)).getText();

                                    actualdataMap.put(MapVal, Table_data);

                                }catch (NoSuchElementException e) {

                                    elementVal = "ElementNotFound";
                                    actualdataMap.put(MapVal, elementVal);

                                }
                            }
                        }
                    }
                }
            }
        }

        Assert.assertEquals(expectedDataMap,actualdataMap);

        HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 2, 5);
        htmlBuilder.addTableHeader("Record ID", "Field Name","Expected Data","Actual Data","Pass/Fail");

        List<Map<String, String>> comparisonResults = ResultsComparator.compareMaps(expectedDataMap, actualdataMap);

        for(Map<String, String> result : comparisonResults) {
            htmlBuilder.addRowValues(result.get("Record No"), result.get("Field Name"),result.get("Expected"),result.get("Actual"),result.get("Pass/Fail"));
        }

        String table = htmlBuilder.build();
        tables.add(table);


        return tables;


    }

    private WebElement getWebElement(String elementId) {
        WebElement element;
        if (elementId.contains("//")) {
            element = driver.findElement(By.xpath(elementId));
        } else {
            element = driver.findElement(By.id(elementId));
        }
        return element;
    }

    private boolean checkWebElement(String elementId) {
        boolean exists;
        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(0));
        if (elementId.contains("//")) {
            exists = !driver.findElements(By.xpath(elementId)).isEmpty();
        } else {
            exists = !driver.findElements(By.id(elementId)).isEmpty();
        }
        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(Constants.DRIVER_IMPLICIT_WAIT_MILLIS));
        return exists;
    }
}
