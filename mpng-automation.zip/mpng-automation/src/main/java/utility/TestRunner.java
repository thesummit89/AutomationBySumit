package main.java.utility;

import com.google.common.collect.Lists;
import org.testng.TestListenerAdapter;
import org.testng.TestNG;

import java.util.List;

public class TestRunner {
    static TestNG testNg;
    public static void main(String[] args) {
        //TestListenerAdapter tla = new TestListenerAdapter();
        TestNG testng = new TestNG();
        List<String> suites = Lists.newArrayList();
        suites.add("test-case-sector.xml");
        suites.add("test-case-custtype.xml");
        testng.setTestSuites(suites);
        testng.run();
    }

}