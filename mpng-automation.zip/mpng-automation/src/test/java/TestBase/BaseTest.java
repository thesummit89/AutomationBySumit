package test.java.TestBase;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import main.java.models.Action;
import main.java.models.TechStep;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.SkipException;
import org.testng.annotations.*;


import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;

import main.java.utility.*;

public class BaseTest {
    private WebDriver driver;
    private ExtentTest extentTest;
    private ExtentReports extentReport;
    private ExtentSparkReporter extentSpark;
    private TestActionExecutor actionExecutor;
    private boolean isWebDriverNeeded = false;
    private String now;
    private String testId;
    List<Map<String, String>> map = new ArrayList<>();

    @BeforeTest
    public void readDataFromExcel(ITestContext context) throws IOException {
        map = CsvUtils.readCsvToListOfMap("RTGSSSSTestCases/testCases/TestData.csv");
       }

    @BeforeClass
    public void setup(){
        driver = WebDriverManager.getDriver();
        extentReport = new ExtentReports();
        now = DateUtil.toDateTimeString(LocalDateTime.now(), "yyyyMMddHHmm");
    }

    @AfterClass
    public void teardown(){
        if (driver != null) driver.quit();
        if (extentReport != null) extentReport.flush();
    }

    // Needed to get the testId from the testng.xml file parameter before the main method is run.
    @BeforeMethod
    public void startTest(ITestContext context) throws IOException {
        testId = context.getCurrentXmlTest().getParameter("testId");
        Map<String, String> testCasePaths = JsonUtils.fromJsonFile("RTGSSSSTestCases/testCases/test-case-path.json", Map.class);
        String testFolderPath = "RTGSSSSTestCases/testCases/"+testCasePaths.get(testId);
        String reportPath = String.format(testFolderPath + "/report/%s/report_%s.html", now, testId);

        Files.createDirectories(Paths.get(String.valueOf(new File(reportPath).getParentFile()))); // Create report folder

        // get test-case.json
        Map<String, String> testCase = JsonUtils.fromJsonFile(testFolderPath+"/test-case.json", Map.class);

        // Create extentTest object here so that it can be passed into the actionExecutor as it is initialised. This allows us to use the extentTest object anywhere in TestActionExecutor
        extentSpark = new ExtentSparkReporter(reportPath);
        extentReport.attachReporter(extentSpark);
        extentTest = extentReport.createTest(context.getName(), testCase.get("description"));

        actionExecutor = new TestActionExecutor(driver, extentTest);

    }
    @BeforeMethod
    public void readRunMode(Method M) {

        try {
            if((boolean) map.get(M.getName().contains("N"))){
                throw new SkipException("Test case skipped as it is set to runmode N");
            }else {
                extentTest = extentReport.startTest(M.getName());
            }


        } catch (Exception e) {
            e.printStackTrace();

        }

        //driver = TC.get().driver;
        return driver;
    }

    @Test
    @Parameters("testId")
    public void executeSingleTest(String testId) throws IOException, SQLException {
        // get test case folder path from test-case-path.json
        Map<String, String> testCasePaths = JsonUtils.fromJsonFile("RTGSSSSTestCases/testCases/test-case-path.json", Map.class);
        String testFolderPath = "RTGSSSSTestCases/testCases/"+testCasePaths.get(testId);
        String reportFolderPath = testFolderPath+"/report/"+now;
        Files.createDirectories(Paths.get(reportFolderPath)); // Create report folder
        Files.createDirectories(Paths.get(reportFolderPath + "/screenshots")); // Create screenshots folder

        // get input flow.json
        String flowFilePath = testFolderPath + "/input/flow.json";
        List<Action> flow = new ObjectMapper().convertValue(JsonUtils.fromJsonFile(flowFilePath, List.class), new TypeReference<List<Action>>() {});
        Collections.sort(flow, Comparator.comparingInt(Action::getSequence));

        List<TechStep> inputTechSteps = new ArrayList<>();

        try {
            for (Action action : flow) {
                    inputTechSteps.addAll(actionExecutor.executeAction(action.getActionType(), action.getData(), testFolderPath, now));
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            // Save inputTechSteps to input.txt file and save file to report folder
            JsonUtils.saveTechStepsToJsonFile(inputTechSteps, reportFolderPath+"/input.json");
        }

        // Perform data comparison (this method needs to be implemented)
//        compareData(expectedData);
    }

    @Test
    @Parameters("scenarioId")
    public void executeBatchTest(String scenarioId) throws IOException, SQLException {
        String testCasePath = "RTGSSSSTestCases/testCases/"+scenarioId;
        // get all folders as list
        // each foldername will be testId
        // pass testId into executeSingleTest

//        for (String testId : ListofTestFolders) {
//             executeSingleTest logic
//            executeSingleTest(testId);
//        }
    }

    private void compareData(Map<String, Map<String, Object>> expectedData) throws SQLException {
        // Implement data comparison logic
    }

}
