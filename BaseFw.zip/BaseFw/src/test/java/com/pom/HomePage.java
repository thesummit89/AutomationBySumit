package com.pom;

import com.basetest.TestBase;
import com.threadConst.TC;
import com.utility.ControlAction;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends TestBase {
    public WebDriver driver;
    public HomePage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[text()='Schedule']")
    public WebElement schedule;

    ControlAction controlAction= TC.get().controlAction;
    public void logintoApp(){
        controlAction.getUrl(properies.getProperty("appUrl"));
        controlAction.actionClickButton(schedule);
    }
}
