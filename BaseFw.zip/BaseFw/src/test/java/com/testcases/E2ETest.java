package com.testcases;

import com.basetest.TestBase;
import com.pom.HomePage;
import com.threadConst.TC;
import com.utility.ControlAction;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.lang.reflect.Method;

public class E2ETest extends TestBase {
    ControlAction controlAction;
    WebDriver driver;
    @BeforeMethod
    @Parameters({"browser"})
    public void launchBrowser(@Optional("chrome") String browser, Method M){
        driver = launchDriver(browser,M);
        controlAction = TC.get().controlAction;

    }

    @Test
    public  void E2ETest1(){
        HomePage page = new HomePage(driver);
        page.logintoApp();
    }
    @Test
    public  void E2ETest2(){
        HomePage page = new HomePage(driver);
        page.logintoApp();
        Assert.fail("Failed");
    }

}
