package com.utility;

public class Cred {

    public Cred(){

    }
}
