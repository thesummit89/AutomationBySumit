import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.time.Duration;

public class test {

    @Test
    public void tst(){
        WebDriver driver = new ChromeDriver();
        driver.get("https://naveenautomationlabs.com/");
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
        driver.manage().window().maximize();
    }
}
