package com.utility;

public class Credentials {

    public Credentials(String env){

    }
}
