package com.threadConst;

public class ThreadInstance {

    public static ThreadConstants createInst(){
        ThreadConstants tc = new ThreadConstants();
        return tc;
    }
}
