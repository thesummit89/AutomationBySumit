package com.nets.sg.test.config;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.nets.sg.test.common.exception.AppException;

@Component
class DataSourceRouting extends AbstractRoutingDataSource {
	
	private final Logger logger = LogManager.getLogger(DataSourceRouting.class);
	private DataSourceContextHolder dataSourceContextHolder;

	private String testDataSourceConfigFilePath;

	private List<DataSourceConnectionConfig> readDatasourceJsonFile() throws AppException {
		Gson gson = new Gson();
		List<DataSourceConnectionConfig> dataSourceConnectionList = new ArrayList<>();
		try (JsonReader jsonReador = new JsonReader(
					new FileReader(this.testDataSourceConfigFilePath))) {

			Type listOfMyClassObject = new TypeToken<ArrayList<DataSourceConnectionConfig>>() {}.getType();
			dataSourceConnectionList = gson.fromJson(jsonReador, listOfMyClassObject);
			if (dataSourceConnectionList == null) {
				dataSourceConnectionList = new ArrayList<>();
			}
		} catch (FileNotFoundException e) {
			logger.error(ErrorCode.DATA_SOURCE_JSON_NOT_FOUND, e);
			throw new AppException(ErrorCode.DATA_SOURCE_JSON_NOT_FOUND, ErrorCode.DATA_SOURCE_JSON_NOT_FOUND.getDescription(), e);
		} catch (JsonIOException | JsonSyntaxException e) {
			logger.error(ErrorCode.DATA_SOURCE_JSON_PARSE_FAILED, e);
			throw new AppException(ErrorCode.DATA_SOURCE_JSON_PARSE_FAILED, ErrorCode.DATA_SOURCE_JSON_PARSE_FAILED.getDescription(), e);
		} catch (IOException e) {
			logger.error(ErrorCode.DATA_SOURCE_JSON_IO_ERROR, e);
			throw new AppException(ErrorCode.DATA_SOURCE_JSON_IO_ERROR, ErrorCode.DATA_SOURCE_JSON_IO_ERROR.getDescription(), e);
		}
		
		return dataSourceConnectionList;
	}
	
	@Override
	protected Object determineCurrentLookupKey() {
		return dataSourceContextHolder.getBranchContext();
	}
	
	private DataSource dataSourceOneDataSource(DataSourceConnectionConfig config) {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setUrl(config.getUrl());
		dataSource.setUsername(config.getUsername());
		dataSource.setPassword(config.getPassword());
		return dataSource;
	}
	
	public DataSourceRouting(DataSourceContextHolder dataSourceContextHolder,
							 @Value("${test.config.path}") String testSuitesFolderPath, @Value("${test.datasource.config.path}") String testDataSourceConfigFilePath) throws AppException {
		this.dataSourceContextHolder = dataSourceContextHolder;

		Map<Object, Object> dataSourceMap = new HashMap<>();
		this.testDataSourceConfigFilePath = testDataSourceConfigFilePath;
		List<DataSourceConnectionConfig> dataSourceConnectionList = this.readDatasourceJsonFile();
		for (DataSourceConnectionConfig dataSourceConnection : dataSourceConnectionList) {
			dataSourceMap.put(dataSourceConnection.getId(), this.dataSourceOneDataSource(dataSourceConnection));
			if(dataSourceConnection.isPrimary()) {
				this.setDefaultTargetDataSource(dataSourceMap.get(dataSourceConnection.getId()));
			}
		}
		this.setTargetDataSources(dataSourceMap);
		
	}
}
