DELETE FROM cbop.common_pending WHERE created_user_id in ('adminuser1');
DELETE FROM cbop.notification WHERE reference_id in ('secmast_20240516_100410.txt');

DELETE FROM cbop.securities WHERE isin in ('MASB99277301', 'SSBLM00000A4', 'SSBLM00000A5');
DELETE FROM cbop.securities_issuance WHERE isin in ('MASB99277301', 'SSBLM00000A4', 'SSBLM00000A5');
DELETE FROM cbop.auction where auction_id in (select auction_id from auction_item where isin in ('MASB99277301',
'SSBLM00000A4', 'SSBLM00000A5'));
DELETE FROM cbop.auction_item WHERE isin in ('MASB99277301', 'SSBLM00000A4', 'SSBLM00000A5');
DELETE FROM cbop.auction_instance where auction_item_id in (select auction_item_id from auction_item where isin in
('MASB99277301', 'SSBLM00000A4', 'SSBLM00000A5'));