package main.java.models;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class TechStep {
    private Integer sequence;
    private String category;
    private String type;
    private String elementId;
    private String textBoxValue;
    private String url;
    private Map<String, String> options;
    private Integer wait;

    // Getters and setters
    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getElementId() {
        return elementId;
    }

    public void setElementId(String elementId) {
        this.elementId = elementId;
    }

    public String getTextBoxValue() {
        return textBoxValue;
    }

    public void setTextBoxValue(String textBoxValue) {
        this.textBoxValue = textBoxValue;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Map<String, String> getOptions() {

        return options;
    }

    public void setOptions(Map<String, String> options) {

        this.options = options;
    }

    public Integer getWait() {
        return wait;
    }

    public void setWait(Integer wait) {
        this.wait = wait;
    }
}
