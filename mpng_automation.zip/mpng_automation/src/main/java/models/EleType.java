package main.java.models;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class EleType {
    private String txtBox;
    private String dropDownBox;
    private Map<String, String> data;

    public String getTextBox() {
        return txtBox;
    }

    public void setTextBox(String txtBox) {

        this.txtBox = txtBox;
    }
    public String getDropDownBox() {
        return dropDownBox;
    }

    public void setDropDownBox(String dropDownBox) {

        this.dropDownBox = dropDownBox;
    }

}
