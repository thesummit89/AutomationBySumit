package main.java.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SqlCreds {
    private String applicationId;
    private String dbUrl;
    private String dbUser;
    private String dbPassword;
}
