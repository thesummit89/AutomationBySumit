package main.java.utility;

import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvException;

public class Merger {
//    public static void main(String[] args) throws IOException {
        // Assuming 'keyColumn' is the name of the column to merge on

//        String file1Path = "RTGSSSSTestCases/testCases/SECTOR/TC01_AddSector/input/AddSectorFormFilling.csv";
//        String file2Path = "modules/sector/elementType/AddSectorFormElementType.csv";
//
//        String[] fileCount = {file1Path,file2Path};
//        Map<String, Set<String>> rowMap = new HashMap<>();
//        for (String file : fileCount) {
//            rowMap = mergeCSVFiles(file, rowMap);
//        }
//        rowMap.entrySet().stream().forEach(System.out::println);
//    }

    public static Map<String, Set<String>> mergeCSVFiles(String filePath, Map<String, Set<String>> rowMap) throws IOException {
        Map<String, String[]> mergedData = new HashMap<>();

        // Read first CSV file and populate the map
        try (CSVReader reader = new CSVReaderBuilder(new FileReader(filePath)).build()) {
            List<String[]> allRows = reader.readAll();
            String[] headers = allRows.get(0);

            int colIndex = 0;
            for (String coloumn : headers) {
                for (int i = 1; i < allRows.size(); i++) {
                    Set<String> temp = rowMap.getOrDefault(coloumn, new HashSet<>());
                    temp.add(allRows.get(i)[colIndex]);
                    rowMap.put(coloumn, temp);
                }
                colIndex++;
            }

        } catch (CsvException e) {
            e.printStackTrace();
        }
        return rowMap;
    }

    public static Map<String, String> mergeInputDataIntoDataTemplate(Map<String, String> templateMap, Map<String, String> inputMap) {
        Map<String, String> mergedMap = new LinkedHashMap<>(templateMap);

        for (Map.Entry<String, String> entry : inputMap.entrySet()) {
            if (mergedMap.containsKey(entry.getKey())) {
                mergedMap.put(entry.getKey(), entry.getValue());
            }
        }

        return mergedMap;
    }

}