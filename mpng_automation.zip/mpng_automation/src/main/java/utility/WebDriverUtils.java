package main.java.utility;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;


import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import static main.java.utility.FileUtils.getConfigPath;

public class WebDriverUtils {
    private WebDriver driver;

    public WebDriverUtils(WebDriver driver) {
        this.driver = driver;
    }

    public void inputText(String elementId, String value) {
        WebElement element = getWebElement(elementId);
        element.clear();
        element.sendKeys(value);
    }

    public void inputFile(String elementId, String value, String testFolderPath) {
        WebElement element = getWebElement(elementId);
        String filePath = testFolderPath + "/input/" + value;
        element.sendKeys(new File(filePath).getAbsolutePath());
    }

    public void dateInputText(String elementId, String value) {
        WebElement element = getWebElement(elementId);
        element.clear();
        element.sendKeys(value);
        element.sendKeys(Keys.RETURN);
        element.sendKeys(Keys.TAB);
    }

    public void click(String elementId) {
        WebElement element = getWebElement(elementId);
        element.click();
    }

    public void SelectUlDrpDwnListItem(String elementid, String listitem) {
        //By element is the xpath as the list items dont have id fields
        List<WebElement> allOptions= driver.findElements(By.xpath(elementid));

        for(int i=0; i<allOptions.size(); i++) {

            if(allOptions.get(i).getText().contains(listitem)) {
                allOptions.get(i).click();
                break;
            }
        }

    }

    public void goToUrl(String url) {
        driver.navigate().to(url);
//        driver.get(url);
    }

    public void getwebtablecelldata(String yourTableId, String headerName){
        // Locate the table
        WebElement table = driver.findElement(By.id(yourTableId));

// Get all header elements
        List<WebElement> headers = table.findElements(By.tagName("th"));
        int headerIndex = -1;

// Find the index of the header
        for (int i = 0; i < headers.size(); i++) {
            if (headers.get(i).getText().equals(headerName)) {
                headerIndex = i;
                break;
            }
        }

// Check if the header is found
        if (headerIndex == -1) {
            throw new RuntimeException("Header not found");
        }

// Iterate through each row and get the cell value based on header index
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row : rows) {
            List<WebElement> cells = row.findElements(By.tagName("td"));
            String cellValue = cells.get(headerIndex).getText();
            // Now you have the cell value, you can do something with it
            System.out.println(cellValue);
        }
    }

    public void formFill(Map<String, String> options, String testFolderPath, String moduleFolderPath) throws IOException {
        // Get csv file path for input
        String inputFileName = options.get("inputFileName");
        String inputFilePath = testFolderPath + "/input/" + inputFileName;

        // Get csv file path for elementType
        String[] parts = options.get("elementTypeFileName").split("\\.", 2);
        String elementTypeFileName = parts[0];
        String elementTypeFileExtension = parts[1];
        String configFilePath = getConfigPath(elementTypeFileName, elementTypeFileExtension, moduleFolderPath).toString();

        // Get each csv file into different lists/maps
        Map<String, String> inputMap = CsvUtils.readCsvToMap(inputFilePath);
        Map<String, String> elementTypeMap = CsvUtils.readCsvToMap(configFilePath);

        // Check for template input file
        String templateFileName;
        if (options.get("templateFileName") != null) {
            templateFileName = options.get("templateFileName");
            String templateFilePath = "RTGSSSSTestCases/dataTemplate/" + templateFileName;
            Map<String, String> templateMap = CsvUtils.readCsvToMap(templateFilePath);

            // Merge input into template
            inputMap = Merger.mergeInputDataIntoDataTemplate(templateMap, inputMap);
        }

        // Loop through each list/map
        // Assumes the columns in the input and elementType are the same size
        for (Map.Entry<String, String> input : inputMap.entrySet()) {
            String elementId = input.getKey(); // get the elementId
            String inputValue = input.getValue(); // get the value from input
            String elementType = elementTypeMap.get(input.getKey()); // get the value from elementType

            System.out.println("elementId: " + elementId + ", inputValue: " + inputValue + ", elementType: " + elementType);
            // handle logic of web element

            switch (elementType) {
                case "textbox":
                    inputText(elementId, inputValue);
                    break;
                case "btn":
                    click(elementId);
                    break;
                case "ulselect":
                    SelectUlDrpDwnListItem(elementId,inputValue);
                    break;
                case "datetextbox":
                    dateInputText(elementId, inputValue);
                    break;

                // add more types here. eg. date picker / radio button
                default:
                    throw new IllegalArgumentException("Unknown element type: " + elementType);
            }

        }
    }

    // Add other WebDriver related utilities as needed

    public void keyValueVerification(Map<String, String> options, String testFolderPath, String moduleFolderPath) throws IOException {
        WebElement actualElement;
        String elementVal;
         Map<String, String> actualdataMap = new LinkedHashMap<String, String>();

        // Get csv file path for elementType
        String[] parts = options.get("elementTypeFileName").split("\\.", 2);
        String elementTypeFileName = parts[0];
        String elementTypeFileExtension = parts[1];
        String elementFilePath = getConfigPath(elementTypeFileName, elementTypeFileExtension, moduleFolderPath).toString();


        // get  review screen element csv file path and call csv util to get a map
        Map<String, String> dataMap = CsvUtils.readCsvToMap(elementFilePath);

        // fetch element from review screen map and fetch element from review screen and create actual data map

        for(Map.Entry m : dataMap.entrySet()){


            actualElement=driver.findElement(By.xpath(m.getValue().toString()));
            elementVal=actualElement.getText();
            actualdataMap.put(m.getKey().toString(),elementVal);

        }

        // get  review screen expected csv file path and call csv util to get a expected data map
        String reviewExpectedfilename = options.get("expectedFileName");
        String reviewExpectedFilePath = testFolderPath + "/expected/" + reviewExpectedfilename;
        Map<String, String> expectedDataMap=CsvUtils.readCsvToMap(reviewExpectedFilePath);
        // Compare two map

        Assert.assertEquals(expectedDataMap,actualdataMap);


    }
    private WebElement getWebElement(String elementId) {
        WebElement element;
        if (elementId.contains("//")) {
            element = driver.findElement(By.xpath(elementId));
        } else {
            element = driver.findElement(By.id(elementId));
        }
        return element;
    }

}
