package main.java.utility;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ExcelUtils {
    public static Map<String, Map<String, Object>> readExpectedData(String reportFolderPath, String reportFileName) throws IOException {
        Map<String, Map<String, Object>> expectedData = new HashMap<>();

        try (FileInputStream fis = new FileInputStream(new File(reportFolderPath, reportFileName));
             Workbook workbook = new XSSFWorkbook(fis)) {

            for (Sheet sheet : workbook) {
                String tableName = sheet.getSheetName();
                Map<String, Object> tableData = new HashMap<>();

                Iterator<Row> rowIterator = sheet.iterator();
                Row headerRow = rowIterator.next();
                Map<Integer, String> headers = new HashMap<>();

                for (Cell cell : headerRow) {
                    headers.put(cell.getColumnIndex(), cell.getStringCellValue());
                }

                while (rowIterator.hasNext()) {
                    Row row = rowIterator.next();
                    Map<String, Object> rowData = new HashMap<>();
                    for (int i = 0; i < headers.size(); i++) {
                        Cell cell = row.getCell(i);
                        rowData.put(headers.get(i), getCellValue(cell));
                    }
                    tableData.put(row.getCell(0).getStringCellValue(), rowData);
                }

                expectedData.put(tableName, tableData);
            }
        }
        return expectedData;
    }

    private static Object getCellValue(Cell cell) {
        DataFormatter formatter = new DataFormatter();
        Object cellValue;
        if (cell == null || cell.getCellType() == CellType.BLANK || formatter.formatCellValue(cell).contains("null")) {
            cellValue = null;
        } else {
            cellValue = formatter.formatCellValue(cell);
        }
        return cellValue;
    }

    public static Map<String, Map<String, Object>> readExpectedData(String s) {
        Map<String, Map<String, Object>> map = null;
        return null;
    }


}
