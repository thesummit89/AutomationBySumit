package main.java.utility;

//import com.google.protobuf.compiler.PluginProtos;
import main.java.constant.AppParameter;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
public class CsvUtils {

    public static Map<String, String> readCsvToMap(String csvFilePath) throws IOException {

        List<String> percentage =
                Files.lines(Paths.get(
                        csvFilePath))
                        .collect(Collectors.toCollection(ArrayList::new));
        //extract only the top row containing headers
        List<String> topRow = Arrays.stream(percentage.get(0).split(",")).collect(Collectors.toList());
        List<String> dataRows = Arrays.stream(percentage.get(1).split(",")).collect(Collectors.toList());
          int topRowSize=topRow.size();
        int dataRowSize=dataRows.size();
        if (topRow.size() == dataRows.size()) {
            Map<String, String> dataMap = new LinkedHashMap<String, String>();
            for (int i = 0; i < topRow.size(); i++) {
                String rowValue = dataRows.get(i);
                // Check for any placeholders eg. $CURVALWEBDATE and replace them
                if (AppParameter.isFieldValueContainsParameter(rowValue)) {
                    rowValue = AppParameter.replaceParameter(rowValue);
                }
                dataMap.put(topRow.get(i), rowValue);
            }
            return dataMap;
        }

        throw new IOException("CSV cannot be converted to Map.");
    }
}
