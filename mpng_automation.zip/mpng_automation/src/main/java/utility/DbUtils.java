package main.java.utility;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.json.Json;
import main.java.models.QueryResult;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import main.java.models.SqlCreds;
import main.java.utility.DateUtil;

import static main.java.utility.DateUtil.toDateTimeString;
import static main.java.utility.FileUtils.getConfigPath;

public class DbUtils {
    // Connection object
    static Connection con = null;
    // Statement object
    private static Statement stmt;
    // Database URL
    public static String dbUrl = null;
    // Database username
    public static String dbUser = null;
    // Database password
    public static String dbPassword = null;

    private static List<String> resultSetArray;

    private static String separator = ",";

    private static String tableName = null;

    public static void setup() throws Exception {
        try {
            // Database connection
            String dbClass = "com.mysql.cj.jdbc.Driver";
            Class.forName(dbClass).newInstance();
            // Get connection to DB
            con = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            // Statement object to send the SQL statement to the Database
            stmt = con.createStatement();
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void getActualDataToCsv(String tableName, String whereClause, String startTime, String testId) {
        try {
            setup();
            resultSetArray = new ArrayList<>();
            String endTime = toDateTimeString(LocalDateTime.now(), "yyyy-MM-dd HH:mm:ss");
            whereClause = whereClause != "" ? whereClause + "and " : whereClause;
            startTime = startTime != null ? ">= '"+startTime+"'" : "is "+null;
            String query = "select * from "+tableName+" where "+whereClause+"modified_timestamp "+startTime+"";
//            String query = "select * from "+tableName+" where "+whereClause+"modified_timestamp BETWEEN '"+startTime+
//                    "' and '"+endTime+"'";
            System.out.println(query);
            fetchDataFromDatabase(query);
            printToCsv(resultSetArray, testId);
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    private static String fetchDataFromDatabase (String selectQuery) throws Exception {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(selectQuery);
            ResultSetMetaData rsmd = rs.getMetaData();
            int numCols = rsmd.getColumnCount();
            tableName = rsmd.getTableName(1); // used when saving csv filename


            // Get table headers
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 1; i <= numCols; i++) {
                stringBuilder.append(String.format(String.valueOf(rsmd.getColumnLabel(i))) + separator);
            }
            resultSetArray.add(stringBuilder.toString());

            // Get table body
            while(rs.next()) {
                StringBuilder sb = new StringBuilder();

                for (int i = 1; i <= numCols; i++) {
                    sb.append(String.valueOf(rs.getString(i)) + separator);
                }
                resultSetArray.add(sb.toString());
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return tableName; // sets tableName to null making csv file output as null
    }

    private static void printToCsv (List<String> resultArray, String testId) throws Exception{
        String now = toDateTimeString(LocalDateTime.now(), "yyyyMMddHHmm");

        testId = testId != null ? "/"+testId : "";

        String folderPath = "./tests/test_case"+testId+"/report/"+now+"/";
        File csvOutputFile = new File(folderPath);
        csvOutputFile.mkdirs(); // create folders based on now
        csvOutputFile = new File(folderPath + tableName +"_"+ now +".csv");
        FileWriter fileWriter = new FileWriter(csvOutputFile, false);

        for(String mapping : resultArray) {
            fileWriter.write(mapping + "\n");
        }

        fileWriter.close();

    }

    public static void executeSql(String sqlFilePath) {
        try{
            SQLExecutor executor = new SQLExecutor(dbUrl, dbUser, dbPassword);
            executor.executeFile(sqlFilePath);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String findIdByQuery(String query) {
        String result = null;
        try{
            setup();
            ResultSet rs = stmt.executeQuery(query);
            result = rs.getObject(1).toString();
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
        return result;
    }

//    public static int calculateOffset (){
//        int offset = 0;
//
//        try {
//            // Get connection to DB
//            con = DriverManager.getConnection(Constants.DB_URL, DB_USER, DB_PASSWORD);
//            Statement stmt = con.createStatement();
//
//            ResultSet rs = stmt.executeQuery("SELECT CURRENT_TIMESTAMP");
//            rs.first();
//
//            String localNow = toDateTimeString(LocalDateTime.now(), "yyyy-MM-dd HH:mm:ss");
//            String dbNow = rs.getString(1);
//
//            offset = DateUtil.findDifference(dbNow, localNow) - Constants.DB_OFFSET_VARIATION_SECONDS;
//            System.out.println("DB is behind local time by: "+offset+" seconds");
//
//            stmt.close();
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//
//        return offset;
//    }

    public static QueryResult queryDatabase(String tableName, Map<String,String> conditions) throws SQLException {
        Map<String, String> results = new HashMap<>();
        StringBuilder queryBuilder = new StringBuilder("SELECT * FROM " + tableName + " WHERE ");

        conditions.forEach((field, value) -> {
            if (value == null || value.contains("null")) {
                queryBuilder.append(field).append(" IS NULL AND ");
            } else {
                queryBuilder.append(field).append(" LIKE '").append(value).append("' AND ");
            }
        });


        String query = queryBuilder.substring(0, queryBuilder.length() - 5); // remove the last " AND "

        try {
            setup();
            ResultSet resultSet = stmt.executeQuery(query);
            System.out.println("Querying: " + query);

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    results.put(columnName, resultSet.getString(columnName));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new QueryResult(query, results);
    }

    public void clearData(Map<String, String> options, String testFolderPath) throws IOException, SQLException {
        // Get SQL credentials from sql_connections.json
        String sqlConnectionsFilePath = "src/test/java/endpoints/sql_connections.json";
        List<SqlCreds> sqlCredsList = new ObjectMapper().convertValue(JsonUtils.fromJsonFile(sqlConnectionsFilePath, List.class), new TypeReference<List<SqlCreds>>() {});

        // Pass in credentials into setup to set the connection
        SqlCreds sqlCreds = sqlCredsList.stream().filter(e->e.getApplicationId().equals(options.get("applicationId"))).findAny().orElse(null);
        dbUrl = sqlCreds.getDbUrl();
        dbUser = sqlCreds.getDbUser();
        dbPassword = sqlCreds.getDbPassword();

        // Get file path to clear_data.sql
        String inputFileName = options.get("fileName");
        String inputFilePath = testFolderPath + "/input/" + inputFileName;

        // Execute SQL query
        executeSql(inputFilePath);
    }
}
