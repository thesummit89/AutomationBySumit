package main.java.utility;

import com.fasterxml.jackson.core.type.TypeReference;
import lombok.Getter;
import lombok.Setter;
import main.java.models.TechStep;

import org.openqa.selenium.WebDriver;



import java.io.IOException;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import static main.java.utility.FileUtils.getConfigPath;

public class TestActionExecutor {
    private WebDriver driver;
    private WebDriverUtils webDriverUtil;
    private ApiUtils apiUtil;
    private DbUtils dbUtil;

    @Getter
    @Setter
    private Map<String, Map<String, Object>> expectedData;

    public TestActionExecutor(WebDriver driver) {
        this.driver = driver;
        this.webDriverUtil = new WebDriverUtils(driver);
        this.apiUtil = new ApiUtils();
        this.dbUtil = new DbUtils();
    }

    public void executeAction(String actionType, Map<String, String> data, String testFolderPath) throws IOException, SQLException {
        String configDirectory = "src/test/java/modules";

        // scans through modules folder for the correct config file
        Path configFilePath = getConfigPath(actionType, "json", configDirectory);

        TypeReference listTypeReference = new TypeReference<List<TechStep>>() {};
        List<TechStep> steps = JsonUtils.fromJsonFileToList(configFilePath.toString(), listTypeReference);
        Collections.sort(steps, Comparator.comparingInt(TechStep::getSequence));


        for (TechStep step : steps) {
            if (data != null) { // passes the info from input into the techstep
                for (Map.Entry<String, String> entry : data.entrySet()) {
                    if (step.getTextBoxValue() != null) {
                        if (step.getTextBoxValue().equalsIgnoreCase("{" + entry.getKey() + "}")) {
                            step.setTextBoxValue(entry.getValue());
                        }
                    }
                    if (step.getOptions() != null) {
                        for(Map.Entry<String, String> option : step.getOptions().entrySet()) {
                            if (option.getValue().equalsIgnoreCase("{" + entry.getKey() + "}")) {
                                option.setValue(entry.getValue());
                            }
                        }
                    }
                }
            }

            // replace

            if (step.getWait() != null) {
                if (step.getWait() > 0) {
                    try {
                        Thread.sleep(step.getWait());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

            switch (step.getCategory()) {
                case "WEB":
                    executeWebStep(step, testFolderPath, configDirectory);
                    break;
                case "API":
                    executeApiStep(step, testFolderPath);
                    break;
                case "SQL":
                    executeSqlStep(step, testFolderPath);
                    break;
                // add more categories if needed. Eg VERIFY
                default:
                    throw new IllegalArgumentException("Unknown action category: " + step.getCategory());
            }

        }
    }


    private void executeWebStep(TechStep step, String testFolderPath, String moduleFolderPath) throws IOException {
        switch (step.getType()) {
            case "url":
                webDriverUtil.goToUrl(step.getUrl());
//                System.out.println(driver.getCurrentUrl());
                break;
            case "input":
//                System.out.println(step.getElementId() + ", " + step.getTextBoxValue());
                webDriverUtil.inputText(step.getElementId(), step.getTextBoxValue());
                break;
            case "click":
//                System.out.println(step.getElementId() + ", click");
                webDriverUtil.click(step.getElementId());
                break;
            case "form_fill":
                webDriverUtil.formFill(step.getOptions(), testFolderPath, moduleFolderPath);
                break;
            case "key_value_verification":
                webDriverUtil.keyValueVerification(step.getOptions(), testFolderPath, moduleFolderPath);
                break;
            case "table_verification":
                break;
            case "input_file":
                webDriverUtil.inputFile(step.getElementId(), step.getTextBoxValue(), testFolderPath);
                break;

            // add more types as needed
            default:
                throw new IllegalArgumentException("Unknown web step type: " + step.getType());
        }
    }

    private void executeApiStep(TechStep step, String testFolderPath) {
        switch (step.getType()) {
            case "uploadFile":
//                apiUtil.uploadFile(step.getOptions(), testFolderPath);
                break;
            case "approve":
//                apiUtil.approve(step.getOptions().get("endpoint"), step.getOptions().get("fileName"));
                break;
            // add more types as needed
            default:
                throw new IllegalArgumentException("Unknown API step type: " + step.getType());
        }
    }

    private void executeSqlStep(TechStep step, String tesFolderPath) throws IOException, SQLException {
        switch (step.getType()){
            case "clear_data":
                dbUtil.clearData(step.getOptions(), tesFolderPath);
                break;
            case "query":
                break;
            // add more types as needed
            default:
                throw new IllegalArgumentException("Unknown SQL step type: " + step.getType());
        }
    }
}
