package main.java.utility;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileUtils {
    public static List<Path> findConfigFiles(String directory, String fileName) throws IOException {
        try (Stream<Path> paths = Files.walk(Paths.get(directory))) {
            return paths
                    .filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().equals(fileName))
                    .collect(Collectors.toList());
        }
    }

    public static Path getConfigPath(String fileName, String fileExtension, String configDirectory) throws IOException {
        List<Path> configPaths = findConfigFiles(configDirectory, fileName + "."+ fileExtension);

        if (configPaths.isEmpty()) {
            throw new IllegalArgumentException("No config file found for action type: " + fileName);
        }

        return configPaths.get(0); // assuming we take the first matching file
    }
}