package main.java.utility;

import java.util.Date;

public final class RandomGenerator {
	
	private static long timestamp = 0;
	
	private RandomGenerator() {
		
	}
	
	public static String getTimestampString() {
		if(timestamp == 0) {
			timestamp = new Date().getTime();
		}else {
			timestamp++;
		}
		return "UNQ" + timestamp;
	}
}
