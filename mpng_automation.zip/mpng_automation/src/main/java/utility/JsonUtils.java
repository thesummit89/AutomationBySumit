package main.java.utility;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

public class JsonUtils {
    //    private static final Gson gson = new Gson();
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static <T> T fromJsonFile(String filePath, Class<T> clazz) throws IOException {
//        try (FileReader reader = new FileReader(filePath)) {
//            return gson.fromJson(reader, clazz);
//        }
        return objectMapper.readValue(new File(filePath), clazz);
    }

    public static <T> List<T> fromJsonFileToList(String filePath, TypeReference<List<T>> typeReference) throws IOException {
//        try (FileReader reader = new FileReader(filePath)) {
//            return gson.fromJson(reader, type);
//        }
        return  objectMapper.readValue(new File(filePath), typeReference);
    }

    public static Map<String, Map<String, Object>> fromJsonFileToMap(String filePath) throws IOException {
//        try (FileReader reader = new FileReader(filePath)) {
//            Type type = new TypeToken<Map<String, Map<String, Object>>>() {}.getType();
//            return gson.fromJson(reader, type);
//        }
        return objectMapper.readValue(new File(filePath), new TypeReference<Map<String, Map<String, Object>>>() {});
    }
}