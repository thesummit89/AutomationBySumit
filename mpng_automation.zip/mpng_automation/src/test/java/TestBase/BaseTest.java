package test.java.TestBase;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import main.java.models.Action;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import java.io.IOException;
import java.sql.SQLException;
import java.time.Duration;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import main.java.utility.*;

public class BaseTest {
    private WebDriver driver;
    private TestActionExecutor actionExecutor;
    private boolean isWebDriverNeeded = false;

    @BeforeClass
    public void setup(){
        driver = WebDriverManager.getDriver();
        actionExecutor = new TestActionExecutor(driver);
    }

    @AfterClass
    public void teardown(){
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    @Parameters("testId")
    public void executeSingleTest(String testId) throws IOException, SQLException {
        String testFolderPath = "RTGSSSSTestCases/testCases/"+testId;
        String flowFilePath = testFolderPath + "/input/flow.json";
        List<Action> flow = new ObjectMapper().convertValue(JsonUtils.fromJsonFile(flowFilePath, List.class), new TypeReference<List<Action>>() {});
        Collections.sort(flow, Comparator.comparingInt(Action::getSequence));

        for (Action action : flow) {
            actionExecutor.executeAction(action.getActionType(), action.getData(), testFolderPath);
        }

        // Perform data comparison (this method needs to be implemented)
//        compareData(expectedData);
    }

    @Test
    @Parameters("scenarioId")
    public void executeBatchTest(String scenarioId) throws IOException, SQLException {
        String testCasePath = "RTGSSSSTestCases/testCases/"+scenarioId;
        // get all folders as list
        // each foldername will be testId
        // pass testId into executeSingleTest

//        for (String testId : ListofTestFolders) {
//             executeSingleTest logic
//            executeSingleTest(testId);
//        }
    }

    private void compareData(Map<String, Map<String, Object>> expectedData) throws SQLException {
        // Implement data comparison logic
    }

}
